<!DOCTYPE html>
<html>
<head>
    <title>Laravel</title>
    <link href="/style.css"   rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <script rel="text/javascript" src="/js/bootstrap.min.js"></script>
    <script rel="text/javascript" src="/js/bootstrap.js"></script>
</head>
<body>
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('about'); ?>
    <?php echo $__env->yieldContent('link'); ?>
</div>
</body>
</html>
