<?php
use Carbon\Carbon;
?>
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
<!-- header -->
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="faq">
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Blog</li>
            </ol>
        </div>
        <div class="agileinfo-news-top-grids">
            <div class="col-md-8 wthree-top-news-left">
                <div class="wthree-news-left">
                    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#home1" id="home1-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Latest News</a></li>
                            <li role="presentation"><a href="#w3bsd" role="tab" id="w3bsd-tab" data-toggle="tab" aria-controls="w3bsd">Movie News</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="home1" aria-labelledby="home1-tab">
                                <?php foreach($news as $new): ?>
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-sm-5 wthree-news-img">
                                            <a href="<?php echo e(action('NewController@newsSingle')); ?>"><img src="<?php echo e(asset('Upload_movies/movies/'. $new->movie_id . '.jpg')); ?>" alt="" />
                                            </a>
                                        </div>
                                        <div class="col-sm-7 wthree-news-info">
                                            <h5><a href="news-single.html"><?php echo e($new['movie_title']); ?>.</a></h5>
                                            <p><?php echo e($new['new_detail']); ?></p>
                                            <ul>
                                                <li><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(\Carbon\Carbon::now()->toDateString()); ?> </li>

                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="w3bsd" aria-labelledby="w3bsd-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-sm-5 wthree-news-img">
                                            <a href="news-single.html"><img src="<?php echo e(url('/assets/images/m17.jpg')); ?>g" alt="" /></a>
                                        </div>
                                        <div class="col-sm-7 wthree-news-info">
                                            <h5><a href="news-single.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></h5>
                                            <p>Sed tristique mattis fermentum. Etiam semper aliquet massa, id tempus massa mattis eget.</p>
                                            <ul>
                                                <li><i class="fa fa-clock-o" aria-hidden="true"></i> 24/09/2016</li>
                                                <li><i class="fa fa-eye" aria-hidden="true"></i> 2642</li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-sm-5 wthree-news-img">
                                            <a href="news-single.html"><img src="<?php echo e(url('/assets/images/m18.jpg')); ?>" alt="" /></a>
                                        </div>
                                        <div class="col-sm-7 wthree-news-info">
                                            <h5><a href="news-single.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></h5>
                                            <p>Sed tristique mattis fermentum. Etiam semper aliquet massa, id tempus massa mattis eget.</p>
                                            <ul>
                                                <li><i class="fa fa-clock-o" aria-hidden="true"></i> 24/09/2016</li>
                                                <li><i class="fa fa-eye" aria-hidden="true"></i> 2642</li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-md-4 wthree-news-right">
                <!-- news-right-top -->
                <div class="news-right-top">
                    <div class="wthree-news-right-heading">
                        <h3>Updated News</h3>
                    </div>
                    <div class="wthree-news-right-top">
                        <div class="news-grids-bottom">
                            <!-- date -->
                            <div id="design" class="date">
                                <div id="cycler">
                                    <div class="date-text">
                                        <a href="news-single.html"><?php echo e(date('Y-m-d')); ?></a>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </div>
                                <script>
                                    function blinker() {
                                        $('.blinking').fadeOut(500);
                                        $('.blinking').fadeIn(500);
                                    }
                                    setInterval(blinker, 1000);
                                </script>
                                <script>
                                    function cycle($item, $cycler){
                                        setTimeout(cycle, 2000, $item.next(), $cycler);

                                        $item.slideUp(1000,function(){
                                            $item.appendTo($cycler).show();
                                        });
                                    }
                                    cycle($('#cycler div:first'),  $('#cycler'));
                                </script>
                            </div>
                            <!-- //date -->
                        </div>
                    </div>
                </div>
                <!-- //news-right-top -->
                <!-- news-right-bottom -->
                <!-- //news-right-bottom -->
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>