<html>
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<body>
<div>

</div>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="faq">
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li>Admin Page</li>
            </ol>
        </div>
        <div class="agileinfo-news-top-grids">
            <div class="col-md-12 wthree-top-news-left">
                <div class="wthree-news-left">
                    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs" role="tablist" >
                            <li role="presentation" class="active"><a href="#home1" id="home1-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">View Profile</a></li>
                            <li role="presentation" ><a href="#home2" id="home2-tab" role="tab" data-toggle="tab" aria-controls="home2" aria-expanded="true">Edit Profile</a></li>
                            <li role="presentation" ><a href="#home3" id="home3-tab" role="tab" data-toggle="tab" aria-controls="home3" aria-expanded="true">Disable Acount</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="home1" aria-labelledby="home1-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-12 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <div class="container col-md-6" style="height: 60%; border: solid 1px gainsboro ">
                                                <div class="col-md-12 row">
                                                    <div class="col-md-2" style="margin-top:2%; height:50%; " >

                                                        <img style="" src="<?php echo e(URL::asset('/Profile/'.Auth::user()['id'].".jpg")); ?>">
                                                    </div>
                                                    <div class="col-md-7 col-md-offset-3" style="margin-top:2%; ">
                                                        <input type="button" class="btn" value="<?php echo e(Auth::user()['name']); ?>" style="margin-top:2%; background-color: #FF8D1B; color: white; width: 100%;">
                                                        <input type="button" class="btn" value="<?php echo e(Auth::user()['email']); ?>" style=" margin-top:5%; background-color: black; color: white; width: 100%;">
                                                        <input type="button" class="btn" value="<?php echo e(Auth::user()['phone']); ?>" style=" margin-top:5%; background-color: #FF8D1B; color: white; width: 100%;">

                                                    </div>
                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                    <div class="clearfix"> </div>
                                </div>
                                <div class="clearfix"> </div>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="home3" aria-labelledby="home3-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-12 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <a href="<?php echo e(action('SessionController@disableAccount')); ?>" class="alert alert-danger">Are user you went to disable your account : <span style="color: blue ; font-size: 14px">Click Here To Confirm</span></a>
                                        </div>
                                    </div>

                                    <div class="clearfix"> </div>
                                </div>
                                <div class="clearfix"> </div>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="home2" aria-labelledby="home2-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form action="<?php echo e(action('SessionController@profileupdate')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="name" class="control-label col-md-3">User Name:</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="name" value="<?php echo e(Auth::user()['name']); ?>">
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="password" class="control-label col-md-3">Password</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="password" class="form-control" name="password">
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="email" class="control-label col-md-3">email</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="email" value="<?php echo e(Auth::user()['email']); ?>">
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="picture" class="control-label col-md-3">profile picture</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="file" class="profile_picture form-control" name="picture">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-offset-8 col-xs-10">
                                                        <button type="submit" class="btn" style="background: #FF8D1B; margin-top: 3%;">update profile</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="clearfix"> </div>
</div>
</div>
</div>

</body>

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>