<?php $__env->startSection('content'); ?>
    <h2>Add a New Song To The List</h2>

 <?php $__env->stopSection(); ?>

<?php $__env->startSection('about'); ?>

        <?php echo Form::open(['route'=>'pages.store']); ?>

           <?php echo $__env->make('form' ,['submitButton'=>"Create Pages"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::close(); ?>


        <?php echo $__env->make('errors.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>