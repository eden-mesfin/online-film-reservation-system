<html>
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<body>
<div>

</div>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="faq">
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li>Admin Page</li>
            </ol>
        </div>
        <div class="agileinfo-news-top-grids">
            <div class="col-md-12 wthree-top-news-left">
                <div class="wthree-news-left">
                    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs" role="tablist" >
                            <li role="presentation" class="active"><a href="#home1" id="home1-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Upload Movie</a></li>
                            <li role="presentation" ><a href="#home2" id="home2-tab" role="tab" data-toggle="tab" aria-controls="home2" aria-expanded="true">Schedule UpNext</a></li>
                            <li role="presentation"><a href="#home3" id="home3-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Reservations</a></li>
                            <li role="presentation"><a href="#home4" id="home4-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Movie Related News</a></li>
                            <li role="presentation"><a href="#home5" id="home5-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Schedule</a></li>
                            <li role="presentation"><a href="#home6" id="home6-tab" role="tab" data-toggle="tab" aria-controls="w3bsd">Messages</a></li>
                            <li role="presentation"><a href="#home7" id="home6-tab" role="tab" data-toggle="tab" aria-controls="w3bsd">Other News</a></li>
                            <li role="presentation"><a href="#home8" id="home6-tab" role="tab" data-toggle="tab" aria-controls="w3bsd">Report and Analysis</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="home1" aria-labelledby="home1-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form class="form-horizontal" action="<?php echo e(action('UploadController@upload')); ?>" method="post" enctype="multipart/form-data">
                                               <?php echo e(csrf_field()); ?>

                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Title</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="movie_title" placeholder="Movie Title">
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Thumbnail</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="file" class="form-control" name="movie_thumbnail" >
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Director</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="director" placeholder="Movie Director">
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Link</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="movie_link" placeholder="Movie Link">
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Plot Summary</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <textarea type="text" class="form-control" name="plot_summary" placeholder="Movie Descripition" style="height:10%;"></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Running Time</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="number" step=".01" class="form-control" name="running_time" placeholder="Running time in minutes">
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Release Date</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="released_date" placeholder="dd/mm/yyyy">
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Genres</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control genres" multiple="multiple" placeholder="select movie genres" name="genres">
                                                            <option>Action</option>
                                                            <option>Adventure</option>
                                                            <option>Animation</option>
                                                            <option>Drama</option>
                                                            <option>Family</option>
                                                            <option>Adventure</option>
                                                            <option>Comedy</option>
                                                            <option>Horror</option>
                                                            <option>Thriller</option>
                                                            <option>Romance</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="selectedGenres" class="form-control" id="selectedGenres" value="">
                                                <div class="form-group">
                                                    <div class="col-xs-offset-10 col-xs-10">
                                                        <button ONCLICK="check_function()" type="submit" class="btn" style="background: #FF8D1B;">Upload</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                        <div class="clearfix"> </div>
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <th>Movie title</th>
                                                <th>Movie Director</th>
                                                <th>Movie Genres</th>
                                                <th>Action</th>
                                            </thead>
                                            <tbody>
                                        <?php foreach($movies as $movie): ?>
                                                 <tr>
                                                     <td><?php echo e($movie->movie_title); ?></td>
                                                     <td><?php echo e($movie->director); ?></td>
                                                     <td><?php echo e($movie->genres); ?></td>
                                                     <td>
                                                         <a href="<?php echo e(action('UploadController@editMovie',$movie->id)); ?>" class="btn btn-info">Edit</a>
                                                         <a href="<?php echo e(action('UploadController@deleteMovie',$movie->id)); ?>" class="btn btn-danger">Delete</a>
                                                     </td>
                                                 </tr>
                                             <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="home2" aria-labelledby="home2-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form class="form-group" action="<?php echo e(action('ScheduleController@upNext')); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Select Movie</label>
                                                    <div class="col-md-7">
                                                        <select class="form-control genres" name="movie_title">
                                                            <?php foreach($movies as $movie): ?>
                                                                <option><?php echo e($movie->movie_title); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group col-md-1 col-md-offset-7">
                                                    <div>
                                                        <button type="submit" class="btn" style="background-color: #FF8D1B;">add to up-next movies</button>
                                                    </div>
                                                </div>
                                            </form>
                                            <table class="table table-condensed table-bordered" style="margin-top: 8%;">
                                                <thead>
                                                <th>Sequence</th>
                                                <th>Movie Title</th>
                                                <th>Action</th>
                                                </thead>
                                                <tbody>

                                                <?php foreach($up_nexts as $key=>$up_next): ?>
                                                    <tr>
                                                        <td><?php echo e($key+1); ?></td>
                                                        <td><?php echo e($up_next['movie_title']); ?></td>
                                                        <td><a href="<?php echo e(action('ScheduleController@removeUpNext',$up_next->id)); ?>" class="btn btn-danger">Remove</a></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="home3" aria-labelledby="home3-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-9 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <div class="form-group" style="padding-bottom: 5%;">
                                                <label for="inputPassword" class="control-label col-md-6">Lis of reservations for room 21</label>

                                            </div>
                                            <div>
                                                <input class="form-control" style="max-width: 50%"  type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for Reserved User" title="Type in a name">

                                            </div>
                                            <table class="table table-condensed table-bordered" id="myTable" style="margin-top: 8%;">
                                                <thead>
                                                <th>number</th>
                                                <th>Movie Title</th>
                                                <th>Seat Number</th>
                                                <th>Reservation Status</th>
                                                <th>Reservation Number</th>
                                                <th>Reserved By</th>
                                                <th>Action</th>
                                                </thead>
                                                <tbody>
                                                <?php $var = 1;?>
                                                <?php foreach($seatPreview as $key=>$seats): ?>
                                                        <tr style="background-color: #2a2930; color: white">
                                                            <td><?php echo e($key+1); ?></td>
                                                            <td><?php echo e($seats->movie->movie_title); ?></td>
                                                            <td><?php echo e($seats->seat_number); ?></td>
                                                            <td><?php echo e($seats->status); ?></td>
                                                            <td><?php echo e($seats->reservation_number); ?></td>
                                                            <td><?php echo e($seats->user->name); ?></td>
                                                            <td><a href="<?php echo e(action('SingleController@deleteSeat',$seats->id)); ?>" class="btn btn-danger"> Remove</a></td>
                                                        </tr>
                                                <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="home4" aria-labelledby="home4-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form class="form-horizontal" action="<?php echo e(action('NewController@store')); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Title</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control genres" name="movie_title">
                                                            <?php foreach($movies as $movie): ?>
                                                                <option><?php echo e($movie->movie_title); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">News Title</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="new_title" placeholder="News Title">
                                                    </div>
                                                </div>

                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">News Detail</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <textarea type="text" class="form-control" name="new_detail" placeholder="Movie Description" style="height:10%;"></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-offset-10 col-xs-10">
                                                        <button type="submit" class="btn" style="background: #FF8D1B;">Add News About Movie</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="home5" aria-labelledby="home5-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form class="form-horizontal" action="<?php echo e(action('ScheduleController@storeSchedule')); ?>"  method="post">
                                                <?php echo e(csrf_field()); ?>


                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Title</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control " name="movie_title">
                                                            <?php foreach($movies as $movie): ?>
                                                             <option><?php echo e($movie->movie_title); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Schedule Date</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="date" class="form-control" name="schedule_date" placeholder="dd-mm-yyyy">
                                                    </div>
                                                </div>

                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Time Range</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control genres" name="time_range">
                                                            <option>range1 - [2:00 - 3:00]</option>
                                                            <option>range2 - [3:00 - 4:00]</option>
                                                            <option>range3 - [4:00 - 5:00]</option>
                                                            <option>range4 - [5:00 - 6:00]</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Cinema Room</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control genres" name="room">
                                                            <option>room1</option>
                                                            <option>room2</option>
                                                            <option>room3</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-offset-8 col-xs-10">
                                                        <button type="submit" class="btn" style="background: #FF8D1B;">Add To Schedule</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div><hr/></div>
                                    <table class="table table-condensed table-bordered col-md-12">
                                        <thead>
                                        <th>Number</th>
                                        <th>Movie Title</th>
                                        <th>Time Range</th>
                                        <th>Cinema Room</th>
                                        <th>Tickets Left</th>
                                        <th>Action</th>
                                        </thead>
                                        <tbody>
                                        <?php foreach($schedules as $key=>$schedule): ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($schedule->movie_title); ?></td>
                                                <td><?php echo e($schedule->time_range); ?></td>
                                                <td><?php echo e($schedule->room); ?></td>
                                                <td><?php echo e($schedule->ticket_left); ?></td>
                                                <td>
                                                    <div class="inline">
                                                        <a class="btn btn-danger" href="<?php echo e(action('ScheduleController@deleteSchedule',$schedule->id)); ?>">Remove</a>
                                                        <a class="btn btn-info" href="<?php echo e(action('ScheduleController@editSchedule',$schedule->id)); ?>">Edit</a>
                                                    </div>

                                                </td>
                                            </tr>

                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="home6" aria-labelledby="home6-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <?php foreach($comments as $comment): ?>
                                            <div>
                                                <p class="col-md-4"><b><?php echo e($comment->user->name); ?></b></p>
                                                <p class="col-md-7">
                                                    <?php echo e($comment['content']); ?>

                                                </p>
                                                <div class="col-md-1" style="margin-top: 3%;">
                                                    <a  href="<?php echo e(action('MessageController@destroy',$comment->id)); ?>" class="btn btn-danger">Remove</a>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="home7" aria-labelledby="home6-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <form class="form-horizontal" action="<?php echo e(action('NewController@othernew')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-group"  style="padding-bottom: 5%;">
                                                <label for="inputEmail" class="control-label col-md-3">News Title</label>
                                                <div class="col-md-8 col-md-offset-1">
                                                    <input type="text" class="form-control" name="new_title" placeholder="News Title">
                                                </div>
                                            </div>

                                            <div class="form-group" style="padding-bottom: 5%;">
                                                <label for="inputPassword" class="control-label col-md-3">News Detail</label>
                                                <div class="col-md-8 col-md-offset-1">
                                                    <textarea type="text" class="form-control" name="new_detail" placeholder="Movie Description" style="height:10%;"></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-xs-offset-10 col-xs-10">
                                                    <button type="submit" class="btn" style="background: #FF8D1B;">Add Other News</button>
                                                </div>
                                            </div>
                                        </form>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>



                            <div role="tabpanel" class="tab-pane fade" id="home8" aria-labelledby="home6-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div>
                                            <table class="table table-striped table-bordered">
                                                <thead>
                                                    <th>Number of Registered User</th>
                                                    <th>Number User Reserved So far</th>
                                                    <th>Number movies uploaded </th>
                                                    <th>Number movies on Schedules </th>
                                                    <th>Number movies on Up coming</th>
                                                </thead>
                                                <tbody>
                                                  <tr>
                                                      <td><?php echo e(count($users)); ?></td>
                                                      <td><?php echo e(count($seatPreview)); ?></td>
                                                      <td><?php echo e(count($movies)); ?></td>
                                                      <td><?php echo e(count($schedules)); ?></td>
                                                      <td><?php echo e(count($up_nexts)); ?></td>

                                                  </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="clearfix"> </div>
    </div>
</div>

</div>


</body>
<script type="text/javascript">
    $(document).ready(function() {
        $(".genres").select2();
        $(".genres").select2();
    });
    function check_function()
    {
        document.getElementById("selectedGenres").value = $(".genres").val();

    }

    function myFunction() {
        var input, filter, table, tr, td, i;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[4];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }

</script>




<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>