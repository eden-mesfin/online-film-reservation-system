<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<script>
    $(document).ready(function() {
        $("#owl-demo").owlCarousel({

            autoPlay: 3000, //Set AutoPlay to 3 seconds

            items : 5,
            itemsDesktop : [640,5],
            itemsDesktopSmall : [414,4]

        });

    });
</script>
<script src="<?php echo e(URL::asset('assets/js/simplePlayer.js')); ?>"></script>

<script>
    $("document").ready(function() {
        $("#video").simplePlayer();
    });
</script>

<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
function rateAlert(id, rating)
{
 //alert( 'Rating for '+id+' is '+rating+' stars!' );
var rating_value1 = rating;

}

$(function() {
$( '.ratebox' ).raterater( {
submitFunction: 'rateAlert',
allowChange: true,
numStars: 5
} );
});



</script>

<form action="<?php echo e(action('NotificationController@rating')); ?>" method="POST" id="form">
    <?php echo e(csrf_field()); ?>


    <input type="hidden" id = "autosubmit" name="value" value="" >
    <input type="hidden" id = "autosubmit" name="movie_id" value="<?php echo e($movie['id']); ?>" >
</form>

<style type="text/css">
    .raterater-bg-layer {
        color: rgba( 0, 0, 0, 0.25 );
    }
    .raterater-hover-layer {
        color: rgba( 255, 255, 0, 0.75 );
    }
    .raterater-hover-layer.rated {
        color: rgba( 255, 255, 0, 1 );
    }
    .raterater-rating-layer {
        color: rgba( 255, 155, 0, 0.75 );
    }
    .raterater-outline-layer {
        color: rgba( 0, 0, 0, 0.25 );
    }
</style>




<!-- single -->
<div class="single-page-agile-main">
    <div class="container">
        <!-- /w3l-medile-movies-grids -->
        <div class="agileits-single-top">
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Single</li>
            </ol>

        </div>
        <div class="single-page-agile-info">
            <!-- /movie-browse-agile -->
            <div class="show-top-grids-w3lagile">
                <div class="col-sm-8 single-left">
                    <div class="song">
<center>
                        <h3><?php echo e($movie->movie_title); ?></h3>
</center>
                        <br>

                        <hr/>

                        <?php if(Auth::check()): ?>
                            <a  style="background-color: #FF8D1B" href="<?php echo e(action('SingleController@singleseat', ['movie_id'=>$movie->id])); ?>" class="btn btn-line btn-default">
                                Reserve A Ticket
                            </a>

                            <?php else: ?>
                            <a class="btn btn-line btn-default disabled" style="color: #FF8D1B">
                                Login to Reserve
                            </a>
                        <?php endif; ?>

                        <div class="modal fade" id="myModal2" >
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span >&times;</span></button>
                                        <h4 class="modal-title" id="myModal2Label">Modal title</h4>
                                    </div>
                                    <div class="modal-body">
                                        <p>Some content on modal</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-theme btn-default" data-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-theme btn-success">Save changes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
<hr/>
                        <div class="video-grid-single-page-agileits">

                            <?php /*<div data-video="dLmKio67pVQ" id="video"> <img src="<?php echo e(URL::asset('/Upload_movies/movies/'.$movie->id.".jpg")); ?>" height="500" alt=""  /> </div>*/ ?>
                            <iframe width="560" height="315" src="<?php echo e($movie->movie_link); ?>" frameborder="0" allowfullscreen></iframe>
                        </div>

                    </div>
                         <div>
						  <ul style="list-style-type:none" >
						    <li>Movie Title :<?php echo e($movie->movie_title); ?></li>
							<li>Movie Description :<?php echo e($movie->plot_summary); ?></li>
							<li>Movie Genre :<?php echo e($movie->genres); ?></li>
							<li>Movie Director :<?php echo e($movie->director); ?></li>
						  </ul>
						 </div>
                          
                        <p>Rate This Movie </p>
						
                        <div class="ratebox" data-id="1" data-rating="<?php echo e($movie->rate['value']); ?>"></div>
                        <div class="clearfix"> </div>

                        <div class="all-comments">
                            <div class="all-comments-info">
                                <a href="#">Comments</a>
                                <div class="agile-info-wthree-box">
                                    <form     action="<?php echo e(action('PostController@storePost')); ?>" method="post" >
                                        <?php echo e(csrf_field()); ?>

                                        <textarea name="content" placeholder="Message" required=""></textarea>
                                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()['id']); ?>">
                                        <input type="hidden" name="movie_id" value="<?php echo e($movie['id']); ?>">
                                        <?php if(Auth::check()): ?>
                                            <input type="submit" value="SEND">
                                        <?php else: ?>
                                            <input type="submit" value="Sign Up Or Login To your Account To leave a Comment" class="btn btn-line btn-default disabled">
                                        <?php endif; ?>

                                        <div class="clearfix"> </div>
                                    </form>
                                </div>
                            </div>
                            <div class="media-grids">
                                <div class="media">

                                    <?php foreach($movie->posts as $post): ?>
                                    <h5><?php echo e($post->user->name); ?></h5>
                                    <div class="media-left">
                                        <a href="#">
                                            <img src="<?php echo e(url('/assets/images/user.jpg')); ?>" title="One movies" alt=" " />
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <p><?php echo e($post->content); ?></p>
                                        <span>posted <?php echo e($post->created_at->addDays(8)->diffForHumans()); ?> </span>
                                    </div>
                                   <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-4 single-right">
                    <h3>Up Next</h3>
                    <div class="single-grid-right">
                        <div class="single-right-grids">
                            <?php foreach($upnexts as $next): ?>
                            <div class="col-md-4 single-right-grid-left">
                                <a href="<?php echo e(action('SingleController@single',$next->movie->id)); ?>"><img src="<?php echo e(URL::asset('/Upload_movies/movies/'.$next->movie->id.".jpg")); ?>"alt="" /></a>
                            </div>
                            <div class="col-md-8 single-right-grid-right">
                                <a href="<?php echo e(action('SingleController@single',$next->movie->id)); ?>" class="title"><?php echo e($next->movie->movie_title); ?></a>
                                <p class="author">Director : <a href="#" class="author"><?php echo e($next->movie->director); ?></a></p>
                                <p class="views">Genres : <a href="#"><?php echo e($next->movie->genres); ?></a></p>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>



                <div class="clearfix"> </div>
            </div>
            <!-- //movie-browse-agile -->
            <!--body wrapper start-->
            <!--body wrapper end-->


        </div>
        <!-- //w3l-latest-movies-grids -->
    </div>
</div>
<!-- //w3l-medile-movies-grids -->

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>