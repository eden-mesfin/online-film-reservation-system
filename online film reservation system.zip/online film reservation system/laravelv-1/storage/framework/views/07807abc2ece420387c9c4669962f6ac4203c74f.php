<?php $__env->startSection('content'); ?>
    <h2>Edit You profile page <?php echo e($page_name->page_name); ?></h2>
<?php /*  <?php echo Form::open(); ?>

  <?php echo Form::label('email','Email Address',['class'=>'awesome']); ?>

  <?php echo Form::text('emial','email@com'); ?><br>
  <?php echo Form::label('password','Password',['class'=>'awesome']); ?>

  <?php echo Form::password('password',['class'=>'awesome']); ?><br>
*/ ?><?php /*    <?php echo Form::checkbox('name','value'); ?><br>
  <?php echo Form::checkbox('name','value',true); ?><br>
  <?php echo Form::radio('name','value',true); ?><br>
  <?php echo Form::radio('name','value',true); ?><br>
  <?php echo Form::radio('name','value',true); ?><br>*/ ?><?php /*
  <?php echo Form::number('name','value'); ?><br>
  <?php echo Form::date('name',\Carbon\Carbon::now()); ?><br>
  <?php echo Form::file('files'); ?><br>
  */ ?><?php /*<?php echo Form::select('size',array('L'=>'Large','S'=>'Small','M'=>'Midiam','G'=>'Greate','O'=>'Option'),null,array('multiple'=>true)); ?>*/ ?><?php /*

  <?php echo Form::select('size',['educational'=>['l'=>'Large','s'=>'verysmall','lo'=>'veryLarge'],'intertiament'=>['s'=>'Small','lo'=>'atsmallLarge']]); ?>


  <br><?php echo Form::selectRange('range',1,10); ?><br>
  <hr>
  <?php echo Form::selectMonth('month'); ?><br>
  <div class="form-group">
      <di class="btn-primary">
          <?php echo Form::submit('Click me'); ?>

          <?php echo Form::close(); ?>

      </di>
  </div>*/ ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('about'); ?>
    <?php echo Form::model($page_name,['route'=>['page_path',$page_name->slog],'method'=>'PATCH']); ?>


        <?php echo $__env->make('form',['submitButton'=>"Update Pages"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo Form::close(); ?>


    <?php echo Form::open(['method'=>'DELETE','route' =>['pages.destroy',$page_name->slog]]); ?>

    <div class="from-group">
        <?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

    </div>
    <?php echo Form::close(); ?>


    <?php echo $__env->make('errors.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>