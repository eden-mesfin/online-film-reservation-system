<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- faq-banner -->
<div class="faq">
    <h4 class="latest-text w3_faq_latest_text w3_latest_text">FAQ</h4>
    <div class="container">
        <div class="panel-group w3l_panel_group_faq" id="accordion" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">
                <?php foreach($faqs as $faq): ?>
                <div class="panel-heading" role="tab" id="headingOne">

                    <h4 class="panel-title asd">
                        <a class="pa_italic" role="button" data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($faq->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i>Frequently asked question
                        </a>
                    </h4>
                </div>
                <div id="<?php echo e($faq->id); ?>" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                    <div style="margin-left: 3% ;margin-top: 2%">
                        <?php echo e($faq->content); ?>

                        <div style="position: relative;left: 5%;top: 2%;" class="media-body">
                            <span>replay for each question can is coming soon</span>
                        </div>

                        <div><hr/></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<!-- //faq-banner -->
<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>