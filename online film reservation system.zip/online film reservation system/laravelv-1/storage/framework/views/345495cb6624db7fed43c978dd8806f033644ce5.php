<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<script>
    $(document).ready(function() {
        $("#owl-demo").owlCarousel({

            autoPlay: 3000, //Set AutoPlay to 3 seconds

            items : 5,
            itemsDesktop : [640,5],
            itemsDesktopSmall : [414,4]

        });

    });
</script>
<script src="js/simplePlayer.js"></script>
<script>
    $("document").ready(function() {
        $("#video").simplePlayer();
    });
</script>

<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- single -->
<div class="single-page-agile-main">
    <div class="container">
        <!-- /w3l-medile-movies-grids -->
        <div class="agileits-single-top">
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Single</li>
            </ol>
        </div>
        <div class="single-page-agile-info">
            <!-- /movie-browse-agile -->
            <div class="show-top-grids-w3lagile">
                <div class="col-sm-8 single-left">
                    <div class="song">

                        <h3>THE LEGEND OF TARZAN - Official Trailer 2</h3>
                        <br>

                        <hr/>

                        <a  href="<?php echo e(action('SingleController@seat')); ?>" class="btn btn-line btn-primary">
                            Reserve A Ticket
                        </a>




                        <div class="modal fade" id="myModal2" >
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span >&times;</span></button>
                                        <h4 class="modal-title" id="myModal2Label">Modal title</h4>
                                    </div>
                                    <div class="modal-body">
                                        <p>Some content on modal</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-theme btn-default" data-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-theme btn-success">Save changes</button>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="video-grid-single-page-agileits">
                            <div data-video="dLmKio67pVQ" id="video"> <img src="<?php echo e(url('/assets/images/5.jpg')); ?>" alt="" class="img-responsive" /> </div>
                        </div>
                    </div>
                    <div>
                        <h4>Share This On :</h4>
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                        <i class="fa  fa-google-plus-circle ()" aria-hidden="true"></i>
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                    </div>
                    <h4 class="title" id="cp-review">Rate this movie : &nbsp;
                        <span class="rate">
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star"></i>
                      <i class="fa fa-star-half-o"></i>
                    </span>
                        <div class="clearfix"> </div>

                        <div class="all-comments">
                            <div class="all-comments-info">
                                <a href="#">Comments</a>
                                <div class="agile-info-wthree-box">
                                    <form>
                                        <textarea placeholder="Message" required=""></textarea>
                                        <input type="submit" value="SEND">
                                        <div class="clearfix"> </div>
                                    </form>
                                </div>
                            </div>
                            <div class="media-grids">
                                <div class="media">
                                    <h5>TOM BROWN</h5>
                                    <div class="media-left">
                                        <a href="#">
                                            <img src="<?php echo e(url('/assets/images/user.jpg')); ?>" title="One movies" alt=" " />
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <p>Maecenas ultricies rhoncus tincidunt maecenas imperdiet ipsum id ex pretium hendrerit maecenas imperdiet ipsum id ex pretium hendrerit</p>
                                        <span>View all posts by :<a href="#"> Admin </a></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-md-4 single-right">
                    <h3>Up Next</h3>
                    <div class="single-grid-right">
                        <div class="single-right-grids">
                            <div class="col-md-4 single-right-grid-left">
                                <a href="single.html"><img src="<?php echo e(url('/assets/images/m1.jpg')); ?>" alt="" /></a>
                            </div>
                            <div class="col-md-8 single-right-grid-right">
                                <a href="single.html" class="title"> Nullam interdum metus</a>
                                <p class="author"><a href="#" class="author">John Maniya</a></p>
                                <p class="views">2,114,200 views</p>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                    </div>
                </div>



                <div class="clearfix"> </div>
            </div>
            <!-- //movie-browse-agile -->
            <!--body wrapper start-->
            <div class="w3_agile_banner_bottom_grid">
                <div id="owl-demo" class="owl-carousel owl-theme">
                    <div class="item">
                        <div class="w3l-movie-gride-agile w3l-movie-gride-agile1">
                            <a href="single.html" class="hvr-shutter-out-horizontal"><img src="<?php echo e(url('/assets/images/m13.jpg')); ?>" title="album-name" class="img-responsive" alt=" " />
                                <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
                            </a>
                            <div class="mid-1 agileits_w3layouts_mid_1_home">
                                <div class="w3l-movie-text">
                                    <h6><a href="single.html">Citizen Soldier</a></h6>
                                </div>
                                <div class="mid-2 agile_mid_2_home">
                                    <p>2016</p>
                                    <div class="block-stars">
                                        <ul class="w3l-ratings">
                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                            <li><a href="#"><i class="fa fa-star-half-o" aria-hidden="true"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="ribben">
                                <p>NEW</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--body wrapper end-->


        </div>
        <!-- //w3l-latest-movies-grids -->
    </div>
</div>
<!-- //w3l-medile-movies-grids -->

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>