<!DOCTYPE html>
<html>
<head>
    <title>Laravel</title>

    <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
    <link href="style.css"   rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="bootstrap/js/bootstrap.js">
    <link rel="stylesheet" href="bootstrap/js/bootstrap.min.js">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

    <style>

    </style>
</head>
<body>
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('about'); ?>
</div>
</body>
</html>
