<div class="form-group <?php echo e($errors->has('page_name') ? 'has-error' : ''); ?>" >
    <div>
        <?php echo Form::label('pagename','Page Name'); ?>

    </div>
    <?php echo Form::text('page_name',null,['class'=>'form-control']); ?>

    <?php echo $errors->first('page_name','<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo e($errors->has('slog')? 'has-error': ''); ?>">
    <div>
        <?php echo Form::label('pagename','Slog of page'); ?>

    </div>
    <?php echo Form::text('slog',null,['class'=>'form-control']); ?>

    <?php echo $errors->first('slog','<span class="help-block">:message</span>'); ?>


</div>

<div class="form-group <?php echo e($errors->has('comment')? 'has-error': ''); ?>">
    <div>
        <?php echo Form::label('pagename','Comment about the pages'); ?>

    </div>
    <?php echo Form::textarea('comment',null,['class'=>'form-control']); ?>

    <?php echo $errors->first('comment','<span class="help-block">:message</span>'); ?>


</div>
<div class="form-group">
    <?php echo Form::submit($submitButton,['class'=>'btn btn-info']); ?>

</div>
