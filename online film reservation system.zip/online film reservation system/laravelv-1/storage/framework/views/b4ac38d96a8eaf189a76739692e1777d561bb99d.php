<html>
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<body>
<div>

</div>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="faq">
    <div class="container">
        <div class="agileits-news-top">
            <ol style="list-style: none">
                <li><h2>Step for Reservation</h2></li>
                <li>
                    <ol>
                        <li>select cinema movies as pick your favorite movies</li>
                        <li>Go to the schedule tabs at the top on menu bar and over view the time it has been scheduled</li>
                        <li>Then navigating to the single movies you picked up from scheduled one</li>
                        <li>Then You can Reserve you seat by clicking on reserve button and the follow the step</li>
                        <li>The pre required for reservation is To Log in into Your Account </li>
                        <li>From notification Copy your secrate key and don't forget its your identity</li>
                        <h3>Other feature of application</h3>
                        <p>you can review upcoming movies</p>
                        <p>you can review news related to specific movies</p>
                        <p>you can review news other than movies related</p>
                    </ol>
                </li>
            </ol>
        </div>
        <div class="agileinfo-news-top-grids">
            <div class="col-md-12 wthree-top-news-left">
                <div class="wthree-news-left">
                    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">

                        <div id="myTabContent" class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="home2" aria-labelledby="home2-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form action="<?php echo e(action('HelpController@store')); ?>" method="post" class="form-horizontal">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="name" class="control-label col-md-4">Asking for help:</label>
                                                    <div class="col-md-7 col-md-offset-1">
                                                        <textarea type="text" class="form-control" name="content" placeholder="write here." ></textarea>
                                                    </div>
                                                </div>
                                                <?php if(Auth::check()): ?>
                                                <div class="form-group">
                                                    <div class="col-xs-offset-8 col-xs-10">
                                                        <button type="submit" class="btn" style="background: #FF8D1B; margin-top: 3%;">Submit Question</button>
                                                    </div>
                                                </div>
                                                 <?php else: ?>
                                                <div class="form-group">
                                                    <div class="col-xs-offset-8 col-xs-10">
                                                        <button type="submit" class="btn disabled" style="background: #FF8D1B; margin-top: 3%;">Sign up Or Log in To Submit Question</button>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </form>

                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="clearfix"> </div>
</div>
</div>
</div>

</body>

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>