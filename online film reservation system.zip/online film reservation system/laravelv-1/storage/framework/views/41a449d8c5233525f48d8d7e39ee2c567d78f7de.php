
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>

<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- /w3l-medile-movies-grids -->
<div class="general">
    <h4 class="latest-text w3_latest_text">Cinema Movies</h4>
    <div class="container">
        <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
            <ul id="myTab" class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">Now Playing</a></li>
                <li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile" aria-expanded="false">Opening This Week</a></li>
                <li role="presentation"><a href="#rating" id="rating-tab" role="tab" data-toggle="tab" aria-controls="rating" aria-expanded="true">Coming Soon</a></li>
                <!--	<li role="presentation"><a href="#imdb" role="tab" id="imdb-tab" data-toggle="tab" aria-controls="imdb" aria-expanded="false">Recently Added</a></li> -->
            </ul>
            <div id="myTabContent" class="tab-content">
                <div role="tabpanel" class="tab-pane fade active in" id="home" aria-labelledby="home-tab">
                        <div class="w3_agile_featured_movies">
                        <div class="col-md-2 w3l-movie-gride-agile">
                            <a href="<?php echo e(action('SingleController@single',$upnext_first->movie->id)); ?>" class="hvr-shutter-out-horizontal"><img src="<?php echo e(URL::asset('/Upload_movies/movies/'.$upnext_first->movie->id.".jpg")); ?>" title="album-name" class="img-responsive" alt=" " />
                                <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
                            </a>
                            <div class="mid-1 agileits_w3layouts_mid_1_home">
                                <div class="w3l-movie-text">
                                    <h6><a href="<?php echo e(action('SingleController@single',$upnext_first->movie->id)); ?>"><?php echo e($upnext_first->movie->movie_title); ?></a></h6>
                                </div>
                            </div>
                            <div class="ribben">
                                <p>NEW</p>
                            </div>
                        </div>
                    </div>

                </div>

                <div role="tabpanel" class="tab-pane fade" id="profile" aria-labelledby="profile-tab">
                    <?php foreach($upnext as $next): ?>
                    <div class="col-md-2 w3l-movie-gride-agile">
                        <a href="<?php echo e(action('SingleController@single',$next->movie->id)); ?>" class="hvr-shutter-out-horizontal"><img src="<?php echo e(URL::asset('/Upload_movies/movies/'.$next->movie->id.".jpg")); ?>" title="album-name" class="img-responsive" alt=" " />
                            <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
                        </a>
                        <div class="mid-1 agileits_w3layouts_mid_1_home">
                            <div class="w3l-movie-text">
                                <h6><a href="<?php echo e(action('SingleController@single',$next->movie->id)); ?>"><?php echo e($next->movie_title); ?></a></h6>
                            </div>
                        </div>
                        <div class="ribben">
                            <p>NEW</p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <div class="clearfix"> </div>
                </div>

                <div role="tabpanel" class="tab-pane fade" id="rating" aria-labelledby="rating-tab">
                    <?php foreach($movies as $movie): ?>
                    <div class="col-md-2 w3l-movie-gride-agile">
                        <a href="<?php echo e(action('SingleController@single',$movie->id)); ?>" class="hvr-shutter-out-horizontal"><img src="<?php echo e(URL::asset('/Upload_movies/movies/'.$movie->id.".jpg")); ?>" title="album-name" class="img-responsive" alt=" " />
                            <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
                        </a>
                        <div class="mid-1 agileits_w3layouts_mid_1_home">
                            <div class="w3l-movie-text">
                                <h6><a href="<?php echo e(action('SingleController@single',$movie->id)); ?>"><?php echo e($movie->movie_title); ?></a></h6>
                            </div>
                        </div>
                        <div class="ribben">
                            <p>NEW</p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- //comedy-w3l-agileits -->
<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>