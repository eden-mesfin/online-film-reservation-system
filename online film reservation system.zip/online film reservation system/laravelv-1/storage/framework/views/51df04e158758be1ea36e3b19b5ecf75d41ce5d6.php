
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- faq-banner -->
<div class="faq">
    <h4 class="latest-text w3_faq_latest_text w3_latest_text">Cinema Schedule</h4>
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Cinema Schedule</li>
            </ol>
        </div>
        <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">

            <div id="myTabContent" class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
                    <div class="agile-news-table">
                        <div class="w3ls-news-result">
                            <h4>Showtime Details :</h4>
                        </div>
                        <table id="table-breakpoint" class="table-bordered table-responsive" style="width: 100%">
                            <thead>
                            <tr>
                                <th>No.</th>
                                <th>Schedule Date</th>
                                <th>Movie Name</th>
                                <th>Release</th>
                                <th>Duration</th>
                                <th>Ticket Left</th>
                                <th>Rome</th>
                                <th>Genre</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php foreach($schedules as $key=>$schedule): ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($schedule->schedule_date); ?></td>
                                        <td><?php echo e($schedule->movie_title); ?></td>
                                        <td><?php echo e($schedule->movies->released_date); ?></td>
                                        <td><?php echo e($schedule->time_range); ?></td>
                                        <td><?php echo e($schedule->ticket_left); ?></td>
                                        <td><?php echo e($schedule->room); ?></td>
                                        <td><?php echo e($schedule->movies->genres); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- //faq-banner -->

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>