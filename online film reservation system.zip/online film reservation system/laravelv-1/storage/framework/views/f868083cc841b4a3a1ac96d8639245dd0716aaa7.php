<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- banner -->
<div id="slidey" style="display:none;">
    <ul>
        <?php foreach($upcaming as $up): ?>
        <li><img src="<?php echo e(URL::asset('/Upload_movies/movies/'.$up->id.".jpg")); ?>" alt=" "><p class='title'>X - Man</p><p class='description'>In 1977, paranormal investigators Ed (Patrick Wilson) and Lorraine Warren come out of a self-imposed sabbatical to travel to Enfield, a borough in north ...</p></li>
        <?php endforeach; ?>
    </ul>
</div>
<script src="<?php echo e(URL::asset('assets/js/jquery.slidey.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/jquery.dotdotdot.min.js')); ?>"></script>
<script type="text/javascript">
    $("#slidey").slidey({
        interval: 8000,
        listCount: 5,
        autoplay: false,
        showList: true
    });
    $(".slidey-list-description").dotdotdot();
</script>
<!-- //banner -->
<!-- banner-bottom -->
<div class="banner-bottom">
    <div class="container">
        <div class="w3_agile_banner_bottom_grid">
            <div id="owl-demo" class="owl-carousel owl-theme">
                <?php foreach($movies as $movie): ?>
                <div class="item">
                    <div class="w3l-movie-gride-agile w3l-movie-gride-agile1">
                        <a href="<?php echo e(action('SingleController@single', ['movie_id'=>$movie->id])); ?>" class="hvr-shutter-out-horizontal"><img src="<?php echo e(URL::asset('/Upload_movies/movies/'.$movie->id.".jpg")); ?>" title="<?php echo e($movie->movie_title); ?>" class="img-responsive" alt=" " />
                            <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
                        </a>
                        <div class="mid-1 agileits_w3layouts_mid_1_home">
                            <div class="w3l-movie-text">
                                <h6><a href="single.html"><?php echo e($movie->movie_title); ?></a></h6>
                            </div>
                            <div class="mid-2 agile_mid_2_home">
                                <div class="ratebox" data-id="1" data-rating="<?php echo e($movie->rate['value']); ?>"></div>
                                <div class="clearfix"> </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="ribben">
                            <p>NEW</p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>

            </div>
        </div>
    </div>
</div>
<!-- //banner-bottom -->

<!-- general -->
<div class="general">
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

</div>
<!-- //general -->
<!-- Latest-tv-series -->
<div class="Latest-tv-series">

</div>

<div id="small-dialog" class="mfp-hide">
    <iframe src="https://player.vimeo.com/video/164819130?title=0&byline=0"></iframe>
</div>
<div id="small-dialog1" class="mfp-hide">
    <iframe src="https://player.vimeo.com/video/148284736"></iframe>
</div>
<div id="small-dialog2" class="mfp-hide">
    <iframe src="https://player.vimeo.com/video/165197924?color=ffffff&title=0&byline=0&portrait=0"></iframe>
</div>
<script>
    $(document).ready(function() {
        $('.w3_play_icon,.w3_play_icon1,.w3_play_icon2').magnificPopup({
            type: 'inline',
            fixedContentPos: false,
            fixedBgPos: true,
            overflowY: 'auto',
            closeBtnInside: true,
            preloader: false,
            midClick: true,
            removalDelay: 300,
            mainClass: 'my-mfp-zoom-in'
        });

    });
</script>
<script>
    function rateAlert(id, rating)
    {
        //alert( 'Rating for '+id+' is '+rating+' stars!' );
        var rating_value1 = rating;

    }

    $(function() {
        $( '.ratebox' ).raterater( {
            submitFunction: 'rateAlert',
            allowChange: true,
            numStars: 5
        } );
    });

</script>


<!-- //Latest-tv-series -->

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>