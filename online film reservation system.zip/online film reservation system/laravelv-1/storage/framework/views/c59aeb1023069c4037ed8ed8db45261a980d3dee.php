<html>
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<body>
<div>

</div>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="faq">
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li>Admin Page</li>
            </ol>
        </div>
        <div class="agileinfo-news-top-grids">
            <div class="col-md-12 wthree-top-news-left">
                <div class="wthree-news-left">
                    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs" role="tablist" >
                            <li role="presentation"><a href="#home5" id="home5-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Edit Schedule</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div role="tabpanel" class="tab-pane fade" id="home5" aria-labelledby="home5-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form class="form-horizontal" action="<?php echo e(action('ScheduleController@updateSchedule' ,$schedule->id)); ?>"  method="post">
                                                <?php echo e(csrf_field()); ?>


                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Title</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control" lass="form-control" name="movie_title">
                                                            <?php foreach($movies as $movie): ?>
                                                                <option ><?php echo e($movie->movie_title); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Schedule Date</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="date" class="form-control" name="schedule_date" value="<?php echo e($schedule->schedule_date); ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Time Range</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control genres" name="time_range">
                                                            <option>range1 - [2:00 - 3:00]</option>
                                                            <option>range2 - [3:00 - 4:00]</option>
                                                            <option>range3 - [4:00 - 5:00]</option>
                                                            <option>range4 - [5:00 - 6:00]</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Cinema Room</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control genres" name="room">
                                                            <option>room1</option>
                                                            <option>room2</option>
                                                            <option>room3</option>
                                                            <option>room4</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-offset-8 col-xs-10">
                                                        <button type="submit" class="btn" style="background: #FF8D1B;">Update Schedule</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div><hr/></div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="clearfix"> </div>
    </div>
</div>

</div>


</body>
<script type="text/javascript">
    $(document).ready(function() {
        $(".genres").select2();
        $(".genres").select2();
    });
    function check_function()
    {
        document.getElementById("selectedGenres").value = $(".genres").val();

    }
</script>

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>