
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('master.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- /w3l-medile-movies-grids -->
<div class="general-agileits-w3l">
    <div class="w3l-medile-movies-grids">

        <!-- /movie-browse-agile -->

        <div class="movie-browse-agile">
            <!--/browse-agile-w3ls -->
            <div class="browse-agile-w3ls general-w3ls">
                <div class="tittle-head">
                    <h4 class="latest-text"><?php echo e($needle); ?> Movies </h4>
                    <div class="container">
                        <div class="agileits-single-top">
                            <ol class="breadcrumb">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">Genres</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="browse-inner">
                        <?php if($count==1): ?>
                        <?php foreach($movies as $movie): ?>
                        <div class="col-md-2 w3l-movie-gride-agile">
                            <a href="<?php echo e(action('SingleController@single', ['movie_id'=>$movie->id])); ?>" class="hvr-shutter-out-horizontal"><img src="<?php echo e(asset('Upload_movies/movies/'. $movie->id . '.jpg')); ?>" title="album-name" alt=" " />
                                <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
                            </a>

                            <div class="mid-1">
                                <div class="w3l-movie-text">
                                    <h6><a href="<?php echo e(action('SingleController@single', ['movie_id'=>$movie->id])); ?>"><?php echo e($movie->movie_title); ?></a></h6>
                                </div>
                                <div class="mid-2">

                                    <p><?php echo e(date('d-m-y')); ?></p>
                                    <div class="block-stars">
                                        <div class="ratebox" data-id="1" data-rating="<?php echo e($movie->rate['value']); ?>"></div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>

                            </div>

                            <div class="ribben two">
                                <p>NEW</p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php else: ?>
                            <h2>No <?php echo e($needle); ?> Movies Found</h2>
                        <?php endif; ?>

                        <div class="clearfix"> </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- //movie-browse-agile -->
        <!--body wrapper start-->
        <!--body wrapper start-->
    </div>
    <!-- //w3l-medile-movies-grids -->
</div>

<script>
    function rateAlert(id, rating)
    {
        //alert( 'Rating for '+id+' is '+rating+' stars!' );
        var rating_value1 = rating;

    }

    $(function() {
        $( '.ratebox' ).raterater( {
            submitFunction: 'rateAlert',
            allowChange: true,
            numStars: 5
        } );
    });



</script>
<?php /*<form action="<?php echo e(action('NotificationController@rating')); ?>" method="POST" id="form">*/ ?>
    <?php /*<?php echo e(csrf_field()); ?>*/ ?>
    <?php /*<input type="hidden" id = "autosubmit" name="value" value="" >*/ ?>
    <?php /*<input type="hidden" id = "autosubmit" name="movie_id" value="<?php echo e($movie['id']); ?>" >*/ ?>
<?php /*</form>*/ ?>
<!-- //comedy-w3l-agileits -->

<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>


</html>