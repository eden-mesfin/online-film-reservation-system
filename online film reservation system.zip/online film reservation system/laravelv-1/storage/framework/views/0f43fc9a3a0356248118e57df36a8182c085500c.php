<?php $__env->startSection('content'); ?>


  <div class="container">
      <div class="well">
          <div class="row">

                      <?php foreach($well as $wel): ?>
                          <div class="col-md-6 btn btn-danger" >
                              <a href="#" style="color:white"><?php echo e($wel->page_name); ?></a>
                          </div>

                          <div class="col-md-6 btn btn-info">
                              <a href="#" style="color: whitesmoke"> <?php echo e($wel->page_number); ?></a>
                          </div>
                            <div class="btn btn-info">
                                <?php echo e($wel->slog); ?>

                            </div>
                  <hr>
                  <br>


                      <?php endforeach; ?>

          </div>

      </div>
  </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>