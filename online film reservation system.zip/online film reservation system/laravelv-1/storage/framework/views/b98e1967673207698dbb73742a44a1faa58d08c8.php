
<!DOCTYPE html>
   <html>
   <head>

      <title>Laravel</title>


      <style>
          .container{
             color: #1f6377;
             align-content: center;
             text-align: center;
          }
      </style>
   </head>
   <body>

   <div class="container">
     <div class="form-group">

        <h2>the second page is displayed</h2>
        <h3><?php echo e($page_name->page_name); ?></h3>
        <h3><?php echo e($page_name->comment); ?></h3>

     </div>
   </div>
   </body>
   </html>




