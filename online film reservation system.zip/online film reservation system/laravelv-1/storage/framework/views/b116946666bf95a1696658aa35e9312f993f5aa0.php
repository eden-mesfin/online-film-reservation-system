<!-- header -->
<div class="header">
    <div class="container">
        <div class="w3layouts_logo">
            <a href="index.html"><h1>Edna<span>Mall</span></h1></a>
        </div>
        <div class="w3_search">
            <form action="<?php echo e(action('GenresController@search')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="text" name="Search" id="search" placeholder="Search" required="">
                <input type="submit" value="Go">
            </form>

        </div>
        <div class="w3l_sign_in_register">
            <ul>
                <?php if(Auth::check()): ?>
                    <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            Welcome, <?php echo e(Auth::user()->name); ?>

                        </a>
                        <ul class="dropdown-menu multi-column">
                            <ul class="multi-column-dropdown">
                                <li><a href="<?php echo e(url('/viewProfile')); ?>">View Profile</a></li>
                                <li><a href="#">Notifications <span class="badge badge-important">+10</span></a></li>
                                <li><a href="<?php echo e(url('/logout')); ?>">LogOut (<?php echo e(Auth::user()->name); ?>)</a></li></li>
                            </ul>

                        </ul>
                <?php else: ?>
                    <li><a href="#" data-toggle="modal" data-target="#myModal">Login / Sign up</a></li>
                <?php endif; ?>


            </ul>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //header -->

<!-- bootstrap-pop-up -->
<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <!-- <?php if(Auth::check()): ?>
                <span>Sign In & Sign Up</span>
            <?php else: ?>    
                <span>Sign Out (name)</span>
            <?php endif; ?>  -->   
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="w3_login_module">
                        <div class="module form-module">
                            <div class="toggle"><i class="fa fa-times fa-pencil"></i>
                                <div class="tooltip">Sign Up</div>
                            </div>
                            <div class="form">
                                <h3>Login to your account</h3>
                                <form action="<?php echo e(route('session.store')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                    <input type="text" name="email" placeholder="email" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <input type="submit" value="Login">
                                </form>
                            </div>
                            <div class="form">
                                <h3>Create an account</h3>
                                <form action="<?php echo e(action('SessionController@userregister')); ?>"  method="post">
                                <?php echo e(csrf_field()); ?>

                                    <input type="text" name="name" placeholder="User name" required="">
                                    <input type="email" name="email" placeholder="Email Address" required="">
                                    <input type="text" name="phone" placeholder="Phone Number" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <input type="submit" value="Register">
                                </form>
                            </div>
                            <div class="cta"><a href="#">Forgot your password?</a></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<div style="max-width: 30%; position: relative ; left: 30%; ">
    <?php if(session('color')==1): ?>
        <?php if(session('feedback')): ?>
            <div class="alert alert-success">
                <?php echo e(session('feedback')); ?>

            </div>
        <?php endif; ?>
    <?php elseif(session('color')==0): ?>
        <?php if(session('feedback')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('feedback')); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>


<script>
    $('.toggle').click(function(){
        // Switches the Icon
        $(this).children('i').toggleClass('fa-pencil');
        // Switches the forms
        $('.form').animate({
            height: "toggle",
            'padding-top': 'toggle',
            'padding-bottom': 'toggle',
            opacity: "toggle"
        }, "slow");
    });
</script>
<!-- //bootstrap-pop-up -->
<!-- nav -->
<div class="movies_nav">
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="navbar-header navbar-left">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <nav>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo e(action('HomeController@home')); ?>">Home</a></li>
                        <li class="dropdown">
                            <a  class="dropdown-toggle" data-toggle="dropdown">Genres <b class="caret"></b></a>
                            <ul class="dropdown-menu multi-column columns-3">
                                <li>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(action('GenresController@action')); ?>">Action</a></li>
                                            <li><a href="<?php echo e(action('GenresController@family')); ?>">Family</a></li>
                                            <li><a href="<?php echo e(action('GenresController@horror')); ?>">Horror</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(action('GenresController@adventure')); ?>">Adventure</a></li>
                                            <li><a href="<?php echo e(action('GenresController@comedy')); ?>">Comedy</a></li>
                                            <li><a href="<?php echo e(action('GenresController@thriller')); ?>">Thriller</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(action('GenresController@animation')); ?>">Animation</a></li>
                                            <li><a href="<?php echo e(action('GenresController@drama')); ?>">Drama</a></li>
                                            <li><a href="<?php echo e(action('GenresController@romance')); ?>">Romance</a></li>
                                        </ul>
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                            </ul>
                        </li>
                        <!--	<li><a href="#">Reservation</a></li> -->
                        <li><a href="<?php echo e(action('NewController@news')); ?>">News</a></li>
                        <li><a href="<?php echo e(action('ScheduleController@schedule')); ?>">Schedule</a></li>
                        <li><a href="<?php echo e(action('ScheduleController@cinema')); ?>">Cinema Movies</a></li>
                        <li><a href="<?php echo e(action('AboutAndContactController@contact')); ?>">Contact Us</a></li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
</div>
<!-- //nav -->
<div class="general_social_icons">
    <nav class="social">
        <ul>
            <li class="w3_twitter"><a href="#">Twitter <i class="fa fa-twitter"></i></a></li>
            <li class="w3_facebook"><a href="#">Facebook <i class="fa fa-facebook"></i></a></li>
            <li class="w3_dribbble"><a href="#">Dribbble <i class="fa fa-dribbble"></i></a></li>
            <li class="w3_g_plus"><a href="#">Google+ <i class="fa fa-google-plus"></i></a></li>
        </ul>
    </nav>
</div>
<script>
    $('#search').hideseek({
        hidden_mode: true
    });
</script>