<!-- header -->
<div class="header">
    <div class="container">
        <div class="w3layouts_logo">
            <a href="index.html"><h1>Edna<span>Mall</span></h1></a>
        </div>
        <div class="w3_search">
            <form action="<?php echo e(action('GenresController@search')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="text" name="Search" id="search" placeholder="Search" required="">
                <input type="submit" value="Go">
            </form>

        </div>
        <div class="w3l_sign_in_register">
            <ul>
                <?php if(Auth::check()): ?>
                    <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            Welcome, <?php echo e(Auth::user()->name); ?>

                        </a>
                        <ul class="dropdown-menu multi-column">
                            <ul class="multi-column-dropdown">
                                <li><a href="<?php echo e(url('/viewProfile')); ?>">View Profile</a></li>
                                <li><a href="#">Notifications <span class="badge badge-important">+10</span></a></li>
                                <li><a href="<?php echo e(url('/logout')); ?>">LogOut (<?php echo e(Auth::user()->name); ?>)</a></li></li>
                            </ul>

                        </ul>
                <?php else: ?>
                    <li><a href="#" data-toggle="modal" data-target="#myModal">Login / Sign up</a></li>
                <?php endif; ?>


            </ul>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //header -->

<!-- bootstrap-pop-up -->
<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <!-- <?php if(Auth::check()): ?>
                <span>Sign In & Sign Up</span>
            <?php else: ?>    
                <span>Sign Out (name)</span>
            <?php endif; ?>  -->   
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <section>
                <div class="modal-body">
                    <div class="w3_login_module">
                        <div class="module form-module">
                            <div class="toggle"><i class="fa fa-times fa-pencil"></i>
                                <div class="tooltip">Sign Up</div>
                            </div>
                            <div class="form">
                                <h3>Login to your account</h3>
                                <form action="<?php echo e(route('session.store')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                    <input type="text" name="email" placeholder="email" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <input type="submit" value="Login">
                                </form>
                            </div>
                            <div class="form">
                                <h3>Create an account</h3>
                                <form action="<?php echo e(action('SessionController@userregister')); ?>"  method="post">
                                <?php echo e(csrf_field()); ?>

                                    <input type="text" name="name" placeholder="User name" required="">
                                    <input type="email" name="email" placeholder="Email Address" required="">
                                    <input type="text" name="phone" placeholder="Phone Number" required="">
                                    <input type="password" name="password" placeholder="Password" required="">
                                    <input type="submit" value="Register">
                                </form>
                            </div>
                            <div class="cta"><a href="#">Forgot your password?</a></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<style type="text/css">
    /* #noti_Container {
        position:relative;
    }*/

    /* A CIRCLE LIKE BUTTON IN THE TOP MENU. */
    #noti_Button {
        margin:-3px 10px 0 10px;
        cursor:pointer;
    }

    /* THE POPULAR RED NOTIFICATIONS COUNTER. */
    #noti_Counter {
        display:block;
        position:absolute;
        background:#E1141E;
        color:#FFF;
        font-size:12px;
        font-weight:normal;
        padding:1px 3px;

        margin-left: 85px;
        border-radius:2px;
        -moz-border-radius:2px;
        -webkit-border-radius:2px;
        z-index:1;
    }

    /* THE NOTIFICAIONS WINDOW. THIS REMAINS HIDDEN WHEN THE PAGE LOADS. */
    #notifications {
        display:none;
        width:430px;
        position:absolute;
        top:70px;
        left:-135px;

        border:solid 1px rgba(100, 100, 100, .20);
        -webkit-box-shadow:0 3px 8px rgba(0, 0, 0, .20);
        z-index: 1;
    }
    /* AN ARROW LIKE STRUCTURE JUST OVER THE NOTIFICATIONS WINDOW */
    #notifications:before {
        content: '';
        display:block;
        width:0;
        height:0;
        color:transparent;

        margin-top:-20px;
        margin-left:10px;
    }

    h3 {
        display:block;
        color:#333;
        background:#FFF;
        font-weight:bold;
        font-size:13px;
        padding:8px;
        margin:0;
        border-bottom:solid 1px rgba(100, 100, 100, .30);
    }

    .seeAll {
        background:#F6F7F8;
        padding:8px;
        font-size:12px;
        font-weight:bold;
        border-top:solid 1px rgba(100, 100, 100, .30);
        text-align:center;
    }
    .seeAll a {
        color:#3b5998;
    }
    .seeAll a:hover {
        background:#F6F7F8;
        color:#3b5998;
        text-decoration:underline;
    }
</style>

<div style="max-width: 30%; position: relative ; left: 30%; ">
    <?php if(session('color')==1): ?>
        <?php if(session('feedback')): ?>
            <div class="alert alert-success">
                <?php echo e(session('feedback')); ?>

            </div>
        <?php endif; ?>
    <?php elseif(session('color')==0): ?>
        <?php if(session('feedback')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('feedback')); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>


<script>
    //Notification

    $(document).ready(function () {

        // ANIMATEDLY DISPLAY THE NOTIFICATION COUNTER.
        $('#noti_Counter')
            .css({ opacity: 0 })
            .text('7')              // ADD DYNAMIC VALUE (YOU CAN EXTRACT DATA FROM DATABASE OR XML).
            .css({ top: '-10px' })
            .animate({ top: '-2px', opacity: 1 }, 500);

        $('#noti_Button').click(function () {
            // TOGGLE (SHOW OR HIDE) NOTIFICATION WINDOW.
            $('#notifications').fadeToggle('fast', 'linear', function () {
                if ($('#notifications').is(':hidden')) {
                    //$('#noti_Button').css('background-color', '#2E467C');
                }
                else
                    $('#noti_Button').css('background-color', 'transparent');        // CHANGE BACKGROUND COLOR OF THE BUTTON.
            });

            $('#noti_Counter').fadeOut('slow');                 // HIDE THE COUNTER.

            return false;
        });
        // HIDE NOTIFICATIONS WHEN CLICKED ANYWHERE ON THE PAGE.
        $(document).click(function () {
            $('#notifications').hide();

            // CHECK IF NOTIFICATION COUNTER IS HIDDEN.
            if ($('#noti_Counter').is(':hidden')) {

            }
        });

        $('#notifications').click(function () {
            return false;       // DO NOTHING WHEN CONTAINER IS CLICKED.
        });
    });
    //end



    $('.toggle').click(function(){
        // Switches the Icon
        $(this).children('i').toggleClass('fa-pencil');
        // Switches the forms
        $('.form').animate({
            height: "toggle",
            'padding-top': 'toggle',
            'padding-bottom': 'toggle',
            opacity: "toggle"
        }, "slow");
    });
</script>
<!-- //bootstrap-pop-up -->
<!-- nav -->
<div class="movies_nav">
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="navbar-header navbar-left">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <nav>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo e(action('HomeController@home')); ?>">Home</a></li>
                        <li class="dropdown">
                            <a  class="dropdown-toggle" data-toggle="dropdown">Genres <b class="caret"></b></a>
                            <ul class="dropdown-menu multi-column columns-3">
                                <li>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(action('GenresController@action')); ?>">Action</a></li>
                                            <li><a href="<?php echo e(action('GenresController@family')); ?>">Family</a></li>
                                            <li><a href="<?php echo e(action('GenresController@horror')); ?>">Horror</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(action('GenresController@adventure')); ?>">Adventure</a></li>
                                            <li><a href="<?php echo e(action('GenresController@comedy')); ?>">Comedy</a></li>
                                            <li><a href="<?php echo e(action('GenresController@thriller')); ?>">Thriller</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-sm-4">
                                        <ul class="multi-column-dropdown">
                                            <li><a href="<?php echo e(action('GenresController@animation')); ?>">Animation</a></li>
                                            <li><a href="<?php echo e(action('GenresController@drama')); ?>">Drama</a></li>
                                            <li><a href="<?php echo e(action('GenresController@romance')); ?>">Romance</a></li>
                                        </ul>
                                    </div>
                                    <div class="clearfix"></div>
                                </li>
                            </ul>
                        </li>
                        <!--	<li><a href="#">Reservation</a></li> -->
                        <li><a href="<?php echo e(action('NewController@news')); ?>">News</a></li>
                        <li><a href="<?php echo e(action('ScheduleController@schedule')); ?>">Schedule</a></li>
                        <li><a href="<?php echo e(action('ScheduleController@cinema')); ?>">Cinema Movies</a></li>

                         <li id="noti_Container"><a href ="" id ="noti_Button" class="fa fa-bell" aria-hidden="true"></a>
                            <!--SHOW NOTIFICATIONS COUNT.-->

                            <div id="noti_Counter">

                            </div>

                            <!--A CIRCLE LIKE BUTTON TO DISPLAY NOTIFICATION DROPDOWN.-->
                            <div id="noti_Button">

                            </div>
                            <!--THE NOTIFICAIONS DROPDOWN BOX.-->
                            <div id="notifications">
                                <h3>Notifications</h3>
                                <div style="height:300px;background-color:white;">
                                    <?php /*<?php foreach($data as $row): ?>*/ ?>
                                        <?php /*<tr>*/ ?>
                                            <?php /*<br/>*/ ?>
                                            <?php /*<td><a href=""><?php echo e($row->notifications); ?></a></td>*/ ?>
                                            <?php /*<td>( <?php echo e($row->created_at); ?>)</td>*/ ?>
                                        <?php /*</tr>*/ ?>
                                        <?php /*<hr>*/ ?>
                                    <?php /*<?php endforeach; ?>*/ ?>


                                </div>
                                <div class="seeAll"><a href="#">See All</a></div>
                            </div>

                        </li>
                        <?php /*<?php endif; ?>*/ ?>
                        <li><a href="<?php echo e(action('AboutAndContactController@contact')); ?>">Contact Us</a></li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
</div>
<!-- //nav -->
<div class="general_social_icons">
    <nav class="social">
        <ul>
            <li class="w3_twitter"><a href="#">Twitter <i class="fa fa-twitter"></i></a></li>
            <li class="w3_facebook"><a href="#">Facebook <i class="fa fa-facebook"></i></a></li>
            <li class="w3_dribbble"><a href="#">Dribbble <i class="fa fa-dribbble"></i></a></li>
            <li class="w3_g_plus"><a href="#">Google+ <i class="fa fa-google-plus"></i></a></li>
        </ul>
    </nav>
</div>
<script>
    $('#search').hideseek({
        hidden_mode: true
    });
</script>