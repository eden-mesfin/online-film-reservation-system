 <?php $__env->startSection('content'); ?>
     About page also here
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('about'); ?>
    <?php foreach($name as $nam): ?>
        <?php /*<li><a href="about/<?php echo e($nam->slog); ?>"><?php echo e($nam->page_name); ?></a></li>*/ ?>
      <li>
          <?php echo link_to_route('page_path',$nam->page_name,[$nam->slog]); ?>


      </li>

    <?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>