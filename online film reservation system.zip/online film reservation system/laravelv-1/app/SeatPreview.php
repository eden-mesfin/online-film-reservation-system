<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SeatPreview extends Model
{
    protected  $fillable =[

        'seat_number',
        'status',
        'user_id',
        'movie_id',
        'reservation_number'
    ];

    public $timestamps = false;


    public function movie()
    {
        return $this->belongsTo('App\Movie' ,'movie_id');

    }

    public function user()
    {
        return $this->belongsTo('App\User');

    }

}
