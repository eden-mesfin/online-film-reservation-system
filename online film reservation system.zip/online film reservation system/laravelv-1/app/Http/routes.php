<?php

Route::get('index','SessionController@index');
Route::get('viewProfile', 'SingleController@profile');
Route::post('profileupdate', 'SessionController@profileupdate');
Route::get('lists','SessionController@lists');
Route::get('sinup','SessionController@create');
Route::get('logout','SessionController@destroy');
Route::get('register','SessionController@register');
Route::get('show','SessionController@show');
Route::post('userregister','SessionController@userregister');
Route::get('delete_user','SessionController@disableAccount');

//Route::post('noti','SessionController@notification');

Route::resource('session','SessionController');
Route::get('single/{movie_id}','SingleController@single');
Route::get('singleseat/{movie_id}','SingleController@singleseat');


//home controller
Route::get('','HomeController@home');


//news
Route::get('news','NewController@news');

//message
Route::post('comment_store','MessageController@store');

Route::get('comments','MessageController@index');
Route::post('messagepost', 'MessageController@messagepost');
Route::get('destroy_comments/{id}','MessageController@destroy');


//admin
Route::get('admin','AdminController@adminDashboard');
Route::get('seat','AdminController@seat');


//reservation
Route::get('seat_store/{movie_id}','SingleController@store');
Route::get('seat_delete/{movie_id}','SingleController@deleteSeat');



###########################################################
//schedule


Route::get('schedule','ScheduleController@schedule');
Route::get('delete_schedule/{id}','ScheduleController@deleteSchedule');

//cinema movies

Route::get('cinema','ScheduleController@cinema');

//up next
Route::post('up_next_movie','ScheduleController@upNext');
Route::get('remove_next_movie/{id}','ScheduleController@removeUpNext');

//store schedule time
Route::post('store_schedule','ScheduleController@storeSchedule');
Route::get('edit_schedule/{id}','ScheduleController@editSchedule');
Route::post('update_schedule/{id}','ScheduleController@updateSchedule');



####################################################################
//Notification
Route::post('rating','NotificationController@rating');
Route::get('delete_notification/{id}','NotificationController@delete');




//contact and about route
Route::get('contact','AboutAndContactController@contact');

//genres route
Route::get('action','GenresController@action');
Route::get('adventure','GenresController@adventure');
Route::get('animation','GenresController@animation');
Route::get('family','GenresController@family');
Route::get('comedy','GenresController@comedy');
Route::get('drama','GenresController@drama');
Route::get('horror','GenresController@horror');
Route::get('thriller','GenresController@thriller');
Route::get('romance','GenresController@romance');
Route::post('search', 'GenresController@search');


//upload_movies process
Route::post('upload','UploadController@upload');
Route::get('edit_movie/{id}','UploadController@editMovie');
Route::get('delete_movie/{id}','UploadController@deleteMovie');
Route::post('update_movie/{id}','UploadController@updateMovie');

//news
Route::post('store_news','NewController@store');
Route::post('other_new','NewController@othernew');
Route::get('delete_new/{id}','NewController@deleteNew');

Route::get('news_single','NewController@newsSingle');
//tests

//posts
Route::post('comments_single','PostController@storePost');

//FAQ
Route::get('faq','FaqController@faq');
//help
Route::get('help','HelpController@help');
Route::post('store_help','HelpController@store');

//subscribe
Route::post('subscribe', 'NewsletterController@subscribe');











