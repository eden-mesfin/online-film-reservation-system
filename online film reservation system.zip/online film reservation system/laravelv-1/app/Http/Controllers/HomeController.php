<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Movie;
use Illuminate\Http\Request;
use App\UpNext;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function home()
    {
        $movies = Movie::all();
        $upcaming = UpNext::all();
        return view('pages.index',compact('movies','upcaming'));
    }
}
