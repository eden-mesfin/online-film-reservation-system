<?php

namespace App\Http\Controllers;

use App\Movie;
use App\Notification;
use App\Post;
use App\Schedule;
use App\SeatPreview;
use App\UpNext;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use Mockery\Matcher\Not;

class SingleController extends Controller
{

    public function seat()
    {

        $data = SeatPreview::all();
        return view('pages.seatPreview',compact('data'));

    }
    public function store(Request $request, $movieId)
    {
        $reserved = SeatPreview::create($request->all());


        $reserved->user_id = Auth::user()->id;

        $reserved->movie_id = $movieId;
        $reserved->reservation_number = Auth::user()->id.$movieId.random_int(1000,9999);
        $reserved->save();
       $movies = DB::table('movies')->where('id', $movieId)->first();
        if($reserved!=null){
             $user_id = Auth::user()->id;
            $schedules_all = Schedule::all();
            $message = "You have successfully made your reservation";
            $notification = Notification::create([
                'user_id' =>$user_id,
                'movie_title'=>$movies->movie_title,
                'seat_number'=>$reserved->seat_number,
                'reservation_number'=>$reserved->reservation_number
            ]);
        }
       return view('pages.schedule' ,compact('message','schedules_all'));

    }

    public function profile()

    {
        return view('pages.viewProfile');
    }

    public function singleseat($movieId){

        $movie = Movie::findOrFail($movieId);
        $data = SeatPreview::all();
        return view('pages.seatPreview', compact(['movie', 'data']));
    }
    public function single($movieId){

        $movie = Movie::findOrFail($movieId);
        $posts =Post::all();
        $upnexts = UpNext::all();
        return view('pages.single', compact('movie','posts','upnexts'));
    }


    public function deleteSeat($id)
    {
        $seat = SeatPreview::find($id);
        $seat->delete();

        return back();
    }

}
