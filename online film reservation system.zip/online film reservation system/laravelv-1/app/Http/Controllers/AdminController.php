<?php

namespace App\Http\Controllers;

use App\Message;
use App\Movie;
use App\Schedule;
use App\SeatPreview;
use App\UpNext;
use App\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use Auth;

class AdminController extends Controller
{
    //

    public function adminDashboard(){
        
        if(Auth::check()){
         
          if(Auth::user()->name=="Supper"){
            $users = User::all();
            $seatPreview = SeatPreview::all();
            $comments = Message::all();
            $movies=Movie::all();
            $up_nexts = UpNext::orderBy('created_at','asc')->get();
            $schedules = Schedule::all();
            return view('pages.test',compact('comments','users','movies','up_nexts','schedules','seatPreview'));
            
         }else{
            return back();
         }

        }else{
            return back();
        }

    }

    public function seat()
    {
        $data = SeatPreview::all();
        return redirect('index')->with('data', $data);
        
    }

    public function index()
    {
        $upcaming = UpNext::all();

        return view('pages.index',compact('upcaming'));

    }


}
