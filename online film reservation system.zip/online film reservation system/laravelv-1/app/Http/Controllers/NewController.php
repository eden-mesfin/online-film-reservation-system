<?php

namespace App\Http\Controllers;

use App\Movie;
use App\MovieNew;
use App\OtherNews;
use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class NewController extends Controller
{


    public function news()

    {

        $movies = Movie::all();
        $movie_news = MovieNew::all();
        $other_news = OtherNews::all();
        $news = OtherNews::latest()->get();
        return view('pages.news',compact(['movies','movie_news','other_news','news']));

    }


    public function store(Request $request ,MovieNew $movie)
    {
        $movie_id= DB::table('movies')->where('movie_title', $request->movie_title)->first();

        $movies = $movie->create(array(
            'movie_title'=>$request->movie_title,
            'new_title'=>$request->new_title,
            'new_detail'=>$request->new_detail,
            'movie_id'=>$movie_id->id
        ));

        return back();
    }

    public function newsSingle()
    {
        return view('pages.news-single');

    }

    public function othernew(Request $request)
    {
        OtherNews::create($request->all());
        return back();
    }

    public function deleteNew($id)
    {
       $movie_news = MovieNew::find($id);
       $movie_news->delete();
       return back();
    }

}
