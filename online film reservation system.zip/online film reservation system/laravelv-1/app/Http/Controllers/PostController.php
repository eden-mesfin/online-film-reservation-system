<?php

namespace App\Http\Controllers;

use App\Post;
use Illuminate\Http\Request;

use App\Http\Requests;

class PostController extends Controller
{

    public function storePost(Request $request)
    {
           Post::create($request->all());
           return back();
    }

}
