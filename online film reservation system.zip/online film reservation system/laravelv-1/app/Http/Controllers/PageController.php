<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Pages;


class PageController extends Controller
{

    public function show(Pages $page_name){

        // $page_name = Pages::whereSlog($slog)->first();
       // $page_name = $slog->get();

        return view('two',compact('page_name'));

    }

    public function edit(Pages $page_name){
       //$page_name = Pages::whereSlog($slog)->first();

        return view('edit',compact('page_name'));
    }

    public function update(Pages $page_name,Requests\PageRequest $reques){
       // $page_name = Pages::whereSlog($slog)->first();

        //best way to do
        //$page_name->fill(['page_name'=>$reques->get('page_name')])-save();
        $page_name->page_name=$reques->get('page_name');
        $page_name->comment =$reques->get('comment');
        $page_name->save();
        return redirect('pages');
    }

  public function  create(){

      return view('create');
  }

    public function store(Requests\PageRequest $request,Pages $page){
        $page->create($request->all());
        return redirect('pages');
        //other very cool validation at controller side
        //$this->validate($request,['name_field'=>'required','name_field'=>'required|min:3']);

    }

    public function destroy(Pages $page){
        $page->delete();
        return redirect('pages');
    }
}
