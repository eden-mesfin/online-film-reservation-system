<?php

namespace App\Http\Controllers;

use App\Faq;
use Illuminate\Http\Request;

use App\Http\Requests;

class FaqController extends Controller
{
    public function faq()
    {

        $faqs = Faq::all();
        return view('pages.faq',compact('faqs'));

    }
}
