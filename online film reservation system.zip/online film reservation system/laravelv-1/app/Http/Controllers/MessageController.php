<?php

namespace App\Http\Controllers;

use App\Message;
use App\Notification;
use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Auth;

class MessageController extends Controller
{
    public function create()
    {

    }
//    public function notify(){
//        $data = Notification::all();
//        return view('pages.index')->with('data',$data);
//    }

    public function store(Request $request)
    {
        $feedback = "";
        if(Auth::check()){
            $messages = Message::create($request->all());
            $messages->user_id = Auth::user()->id;
            $messages->save();

            $feedback = "Thank you For your Comment: " . Auth::user()->name;
            return back()->with(['feedback'=>$feedback,'color'=>1]);

        }
         $feedback = "You Have To Register To Leave a Comment Or LogIn To Your Account";
         return back()->with(['feedback'=>$feedback,'color'=>0]);
    }

    public function index()
    {
        
    }

    public function destroy($id)
    {
        $message = Message::find($id);
        $message->delete();
        return back();
    }
}
