<?php

namespace App\Http\Controllers;

use App\Movie;
use Illuminate\Http\Request;

use App\Http\Requests;

class UploadController extends Controller
{
    public function upload(Request $request ,Movie $movie)
    {
        $genre = $request['selectedGenres'];

             $movies = $movie->create(array(
            'movie_title'=>$request->movie_title,
            'director'=>$request->director,
            'movie_link'=>$request->movie_link,
            'plot_summary'=>$request->plot_summary,
            'running_time'=>$request->running_time,
            'released_date'=>$request->released_date,
            'genres'=>$genre,
    ));

        $movie_title = $request->file('movie_thumbnail')->getClientOriginalExtension();
        $request->file('movie_thumbnail')->move(public_path() . '/Upload_movies/movies/', $movies->id.".".$movie_title);

        return back();


    }

    public function deleteMovie($id)
    {
        $movie = Movie::find($id);
        $movie->delete();
        return back();
    }

    public function editMovie($id)
    {
        $movie = Movie::find($id);
        return view('pages.edit_movie',compact('movie'));
    }

    public function updateMovie(Request $request ,$id)
    {
        $movie = Movie::find($id);

         $genre = $request['selectedGenres'];

            $movie->movie_title=$request->movie_title;
            $movie->director=$request->director;
            $movie->movie_link=$request->movie_link;
            $movie->plot_summary=$request->plot_summary;
            $movie->running_time=$request->running_time;
            $movie->released_date=$request->released_date;
            $movie->genres=$genre;
            $movie->update();

        $movie_title = $request->file('movie_thumbnail')->getClientOriginalExtension();
        $request->file('movie_thumbnail')->move(public_path() . '/Upload_movies/movies/', $movie->id.".".$movie_title);

        return redirect('admin');

    }

}
