<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Movie;
use App\MovieNew;
use App\UpNext;
use Illuminate\Http\Request;
use Auth;
// use Input;
use App\User;
use Hash;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use App\Http\Requests;

class SessionController extends Controller
{
    
 public function create(){
 	return view('auth.login');
 }


public function store(){
   

	if (Auth::attempt(Input::only('email','password'))){
	    
        
        $movies = Movie::all();
        $upcaming = UpNext::all();
		return view('pages.index',compact('movies','upcaming'));
	}else{
        return back()->with('message','Your password or email is wrong');
    }


}


public function register(){

     return view('auth.register');
}

public function userregister(UserRequest $request){

     $requests = $request->all();
     $requests['password']=Hash::make($request['password']);
     $user = User::create($requests);


    if($user!=null){
        if (Auth::attempt(Input::only('email','password'))){

            $upcaming = UpNext::all();
            $movies = Movie::all();
            return view('pages.index',compact('movies','upcaming'));
        }
        $movies = Movie::all();
        $upcaming = UpNext::all();
        return view('pages.index',compact('movies','upcaming'));
     }else{
     	return back();
     }

}
public function profileupdate(Request $request){

        $pass = Hash::make($request['password']);
        DB::table('users')->where('id', Auth::user()->id)->update(
            [
                'name'=> $request['name'],
                'password'=>$pass,
                'email'=>$request['email']
            ]
        );
    $extension = $request->file('picture')->getClientOriginalExtension();
    $request->file('picture')->move(public_path() . '/Profile/', Auth::user()->id.".".$extension);


        return Redirect::to('viewProfile');
    }
public function show(User $users){

     return $users->all();

}

public function index(){

    $movies = Movie::all();
    $upcaming = UpNext::all();
	return view('pages.index',compact('movies','upcaming'));
}

public function lists(){

	return view('pages.list');
}


public function destroy(){
	 Auth::logout();
     $movies = Movie::all();
	return Redirect::to('index');
}

public function notification(){
    $data = Notification::all();
    $upcaming = UpNext::all();

    return view('pages.index' ,compact('upcaming'))->with('data',$data);
}

    public function disableAccount()
    {
        if(Auth::check()){
            $user = User::findOrFail(Auth::user()->id);

            $user->delete();
            $upcaming = UpNext::all();

            return Redirect::to('index');

        }else{
            return back();
        }
    }


}
