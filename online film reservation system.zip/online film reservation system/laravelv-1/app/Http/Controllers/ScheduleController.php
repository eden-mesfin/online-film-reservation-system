<?php

namespace App\Http\Controllers;

use App\Movie;
use App\MovieNew;
use App\Schedule;
use App\SeatPreview;
use App\UpNext;
use App\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Message;
use Illuminate\Support\Facades\DB;

class ScheduleController extends Controller
{
    public function schedule()

    {
        $movies = Movie::all();
        $schedules_all = Schedule::all();

        return view('pages.schedule',compact(['movies','schedules_all']));
    }

    public function cinema()
    {
        $upnext = UpNext::all();
        $upnext_first = UpNext::first();
        $movies = Movie::all();
        return view('pages.cinemamovies',compact('upnext','upnext_first','movies'));

    }


    public function upNext(Request $request)
    {
        $movie_id = DB::table('movies')->where('movie_title',$request->movie_title)->first();

         UpNext::create([
             'movie_title'=>$request->movie_title,
             'movie_id'=>$movie_id->id,
         ]);

        return back();
        
    }

    public function storeSchedule(Request $request ,Schedule $schedule)
    {

        $movie_id= DB::table('movies')->where('movie_title', $request->movie_title)->first();
        $schedules = $schedule->create(array(
            'movie_id'=>$movie_id->id,
            'movie_title'=>$request->movie_title,
            'schedule_date'=>$request->schedule_date,
            'time_range'=>$request->time_range,
            'room'=>$request->room
        ));
        return back();

    }


    public function removeUpNext($id)
    {
         $upnext = UpNext::find($id);
         $upnext->delete();
         return back();

    }


    public function deleteSchedule($id)
    {
        $schedule = Schedule::find($id);
        $schedule->delete();
        return back();

    }

    public function editSchedule($id)
    {
        $movies = Movie::all();
        $schedule = Schedule::find($id);
        return view('pages.edit_schedule' ,compact('movies','schedule'));

    }

    public function updateSchedule(Request $request,$id)
    {
       $schedule =Schedule::find($id);
        $movie_id= DB::table('movies')->where('movie_title', $request->movie_title)->first();
        $schedule->movie_id = $movie_id->id;
        $schedule->movie_title = $request->movie_title;
        $schedule->schedule_date = $request->schedule_date;
        $schedule->time_range = $request->time_range;
        $schedule->room = $request->room;
        $schedule->update();

        return redirect('admin');

    }



}
