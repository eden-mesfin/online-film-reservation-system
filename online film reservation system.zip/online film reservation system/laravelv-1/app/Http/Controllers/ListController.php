<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class ListController extends Controller
{

    public function home()
    {
        $upcaming = UpNext::all();

        return view('pages.index',compact('upcaming'));
    }
}
