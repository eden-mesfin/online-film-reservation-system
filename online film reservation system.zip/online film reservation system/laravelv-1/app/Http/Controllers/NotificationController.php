<?php

namespace App\Http\Controllers;

use App\Rate;
use App\Schedule;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class NotificationController extends Controller
{
    //
    public function index(){
        $data = Notification::all();
        $data2 = Schedule::all();
        $upcaming = UpNext::all();

        return view('pages.index',compact('upcaming'))->with('data',$data);
    }

    public function rating(Request $request)
    {
        if(Auth::check()){

            $movie_id=$request->movie_id;
            $is_movie_id = DB::table('rates')->where('movie_id',$movie_id)->first();
            if($is_movie_id!==null){
                $counter = $is_movie_id->counter+1;
                $value = ($is_movie_id->value + $request->value)/2;
                DB::table('rates')->where('movie_id',$movie_id)->update([
                    'counter'=>$counter,
                    'value'=>$value,
                ]);
                return back();
            }else{
                $rate = Rate::create([
                    'counter'=>1,
                    'movie_id'=>$movie_id,
                    'value'=>$request->value
                ]);
                return back();
            }

        }else{

            return back()->with('message','You have to Sign up Or Log in To you account to rate this Movie');
        }



    }

    public function delete(Request $request,$id)
    {
        $notification =Notification::find($id);
        $notification->delete();
        return back();

    }


}
