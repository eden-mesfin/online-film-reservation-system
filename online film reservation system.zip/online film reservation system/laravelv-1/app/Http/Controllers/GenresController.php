<?php

namespace App\Http\Controllers;
use App\Movie;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use App\Http\Requests;

class GenresController extends Controller
{
    public function action()
    {

        $needle = 'Action';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }


    }
    public function adventure()
    {
        $needle = 'Adventure';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }

    }
    public function animation()
    {
        $needle = 'Animation';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }

    }
    public function family()
    {
        $needle = 'Family';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }
    }
    public function comedy()
    {
        $needle = 'Comedy';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }


    }
    public function drama()
    {
        $needle = 'Drama';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }



    }
    public function horror()
    {
        $needle = 'Horror';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }


    }
    public function thriller()
    {
        $needle = 'Thriller';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }


    }
    public function romance()
    {
        $needle = 'Romance';

        $movies = Movie::where('genres', 'LIKE', '%'.$needle.'%')->get();

        if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }

    }
    public function search(Request $request)
    {
        
        $title = $request['Search'];
        $needle = 'Search result';

        $movies = Movie::where('movie_title', $title)->get();
         if(count($movies)!=0){
            $count =1;
            return view('pages.genres', compact('movies', 'needle','count'));
        }else{
            $count=0;
            return view('pages.genres', compact('movies', 'needle','count'));
        }

    }






}
