<?php

namespace App\Http\Controllers;

use App\Faq;
use Illuminate\Http\Request;

use App\Http\Requests;

class HelpController extends Controller
{
    public function help()
    {
        return view('pages.help');
    }

    public function store(Request $request )
    {
       $faq =  Faq::create($request->all());

       if($faq!==null){
           return back();
       }
       return back();
    }
}
