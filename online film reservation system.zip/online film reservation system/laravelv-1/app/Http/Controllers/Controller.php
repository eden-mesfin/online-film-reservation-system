<?php

namespace App\Http\Controllers;

use App\Pages;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
class Controller extends BaseController
{
    private $page;
    public function __construct(Pages $page)

    {
        $this->page=$page;

    }

//    use AuthorizesRequests, AuthorizesResources, DispatchesJobs, ValidatesRequests;
   public function index(){
       //$well = Pages::get();
     //  $well = $this->get();
       $name = $this->page->latest()->get();
       return view('about',compact('name'));
   }


}
