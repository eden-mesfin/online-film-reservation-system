<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\Movie;
class Schedule extends Model
{
    protected  $fillable = [
        'movie_title',
        'schedule_date',
        'time_range',
        'room',
        'movie_id',

    ];


    public function movies()
    {
        return $this->belongsTo('App\Movie','movie_id');
    }
}
