<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MovieNew extends Model
{
    protected $fillable = [
       'movie_title',
       'new_title',
       'new_detail',
        'movie_id'
    ];
}
