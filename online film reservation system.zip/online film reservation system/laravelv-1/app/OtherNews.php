<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OtherNews extends Model
{
   protected  $fillable=[
       'new_title',
       'new_detail'
   ];
}
