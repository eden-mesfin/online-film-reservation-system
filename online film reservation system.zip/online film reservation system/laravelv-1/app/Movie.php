<?php

namespace App;
use App\Schedule;

use Illuminate\Database\Eloquent\Model;


class Movie extends Model
{
    protected $fillable=[
       'movie_title',
       'movie_thumbnail',
       'director',
       'movie_link',
       'plot_summary',
       'running_time',
       'released_date',
       'genres',
    ];

    public function schedule()
    {
        return $this->hasMany('App\Schedule');
    }

    public function SeatPreview()
    {
        return $this->hasMany('App\SeatPreview');
    }

    public function rate()
    {

        return $this->hasOne('App\Rate','movie_id');
    }

    public function posts()
    {
        return $this->hasMany('App\Post','movie_id');

    }

    public function upnexts()
    {
        return $this->hasMany('App\UpNext');

    }

    public function seat()
    {
        return $this->hasMany('App\SeatPreview');

    }

}
