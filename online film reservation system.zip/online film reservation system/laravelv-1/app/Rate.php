<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rate extends Model
{
    protected  $fillable=[
        'counter',
        'movie_id',
        'value',

    ];

    public function movie()
    {
        return $this->belongsTo('App\Movie');

    }
}
