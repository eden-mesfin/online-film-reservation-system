<?php
/**
 * Created by PhpStorm.
 * User: feyo
 * Date: 11/29/2016
 * Time: 12:04 PM
 */

namespace App;
use Illuminate\Database\Eloquent\Model as Eloquent;


class Pages extends Eloquent
{
 protected $fillable=[
     'slog','comment','page_name'
 ];
}