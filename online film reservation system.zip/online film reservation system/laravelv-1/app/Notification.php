<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    //

    protected  $fillable = [
         'user_id',
        'movie_title',
        'seat_number',
        'reservation_number'
    ];

    public function user()
    {
        return $this->belongsTo('App\User');
    }


}
