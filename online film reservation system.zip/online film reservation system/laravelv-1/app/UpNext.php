<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UpNext extends Model
{
     protected  $fillable =[
         'movie_title',
         'movie_id',
         ];

    public function movie()
    {
        return $this->belongsTo('App\Movie');

     }
}
