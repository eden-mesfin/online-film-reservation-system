<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Message;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function comments()
    {
        return $this->hasMany('App\Message');

    }
    public function SeatPreview()
    {
        return $this->hasMany('App\SeatPreview');
    }

    public function posts()
    {
        return $this->hasMany('App\Post');

     }

    public function seat()
    {
        return $this->hasMany('App\SeatPreview');

     }

    public function notifications()
    {
        return $this->hasMany('App\Notification');
     }

}
