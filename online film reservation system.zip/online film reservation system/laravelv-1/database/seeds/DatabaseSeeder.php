<?php

use Illuminate\Database\Seeder;
use ElluminateDatabaseEloquentModel;
use IlluminateDatabaseEloquentModel;
use AppUser;
use AppTimeEntry;


class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return voi
     */
    public function run()
    {
//         $this->call(UsersTableSeeder::class);
//         $this->call(PageEntriesSeeder::class);
    }
}

