@extends('layouts.app')
@section('content')
    <div class="container well">

        @foreach($users as $user)
            <div class="form-control">
                <li class="glyphicon-text-color">
                    {{$user->name}}
                </li>
                <li>
                    {{$user->email}}
                </li>

            </div>
            <hr>
        @endforeach
    </div>

@endsection