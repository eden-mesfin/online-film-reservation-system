
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

@include('master.links')

<body>

@include('master.header')

<!-- faq-banner -->
<div class="faq">
    <h4 class="latest-text w3_faq_latest_text w3_latest_text">Cinema Schedule</h4>
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Cinema Schedule</li>
            </ol>
        </div>
        <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">

            <div id="myTabContent" class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
                    <div class="agile-news-table">
                        <div class="w3ls-news-result">
                            <h4>Showtime Details :</h4>
                        </div>
                        <table id="table-breakpoint" class="table-bordered table-responsive" style="width: 100%">
                            <thead>
                            <tr>
                                <th>No.</th>
                                <th>Schedule Date</th>
                                <th>Movie Name</th>
                                <th>Release</th>
                                <th>Duration</th>
                                <th>Rome</th>
                                <th>Genre</th>
                            </tr>
                            </thead>
                            <tbody>
                                @foreach($schedules_all as $key=>$schedule)
                                    <tr>

                                        <td>{{$key+1}}</td>
                                        <td>{{$schedule->schedule_date}}</td>
                                        <td>

                                            <a href="{{action('SingleController@single',$schedule->movie_id)}}">
                                                {{$schedule->movie_title}}
                                            </a>
                                        </td>
                                        <td>{{$schedule->movies->released_date}}</td>
                                        <td>{{$schedule->time_range}}</td>
                                        <td>{{$schedule->room}}</td>
                                        <td>{{$schedule->movies->genres}}</td>
                                    </tr>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- //faq-banner -->

@include('master.footer')

</body>
</html>