<?php
use Carbon\Carbon;
?>
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

@include('master.links')

<body>
<!-- header -->
@include('master.header')

<div class="faq">
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Blog</li>
            </ol>
        </div>
        <div class="agileinfo-news-top-grids">
            <div class="col-md-8 wthree-top-news-left">
                <div class="wthree-news-left">
                    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#home1" id="home1-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Movie News</a></li>
                            <li role="presentation"><a href="#w3bsd" role="tab" id="w3bsd-tab" data-toggle="tab" aria-controls="w3bsd">Latest News</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="home1" aria-labelledby="home1-tab">
                                @foreach($movie_news as $movie_new)
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-sm-5 wthree-news-img">
                                            <a href="{{action('SingleController@single',$movie_new->id)}}"><img src="{{asset('Upload_movies/movies/'. $movie_new->movie_id . '.jpg') }}" alt="" />
                                            </a>
                                        </div>
                                        <div class="col-sm-7 wthree-news-info">
                                            <h5><a href="{{action('SingleController@single',$movie_new->id)}}">{{$movie_new['movie_title']}}.</a></h5>
                                            <p>{{$movie_new['new_detail']}}</p>
                                            <ul>
                                                <li><i class="fa fa-clock-o" aria-hidden="true"></i> {{ \Carbon\Carbon::now()->toDateString() }} </li>

                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                    @if(Auth::check())
                                        @if(Auth::user()->name=="Admin")
                                         <a href="{{action('NewController@deleteNew',$movie_new->id)}}" style="position: relative;left: 50%" class="btn btn-danger">Remove</a>
                                        @endif
                                    @endif
                                </div>
                                @endforeach
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="w3bsd" aria-labelledby="w3bsd-tab">
                                <div class="wthree-news-top-left">
                                    <table class="table table-condensed">
                                        @foreach($other_news as $other_new)
                                            <tr>
                                                <td>
                                                {{$other_new->new_title}}
                                                </td>
                                                <td>
                                                {{$other_new->new_detail}}
                                                </td>
                                            </tr>
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 wthree-news-right">
                <!-- news-right-top -->
                <div class="news-right-top">
                    <div class="wthree-news-right-heading">
                        <h3 style="color: deepskyblue">Updated News</h3>
                    </div>
                    <div class="wthree-news-right-top">
                        <div class="news-grids-bottom">
                            <!-- date -->
                            <div id="design" class="date">
                                <div id="cycler">
                                    <div class="date-text">
                                        <a href="#">{{ date('Y-m-d') }}</a>
                                        @foreach($news as $new)
                                            <p>{{$new->new_detail}}</p>
                                            <div>
                                                <hr></div>
                                        @endforeach
                                    </div>
                                </div>
                                <script>
                                    function blinker() {
                                        $('.blinking').fadeOut(500);
                                        $('.blinking').fadeIn(500);
                                    }
                                    setInterval(blinker, 1000);
                                </script>
                                <script>
                                    function cycle($item, $cycler){
                                        setTimeout(cycle, 2000, $item.next(), $cycler);

                                        $item.slideUp(1000,function(){
                                            $item.appendTo($cycler).show();
                                        });
                                    }
                                    cycle($('#cycler div:first'),  $('#cycler'));
                                </script>
                            </div>
                            <!-- //date -->
                        </div>
                    </div>
                </div>
                <!-- //news-right-top -->
                <!-- news-right-bottom -->
                <!-- //news-right-bottom -->
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>

@include('master.footer')

</body>
</html>