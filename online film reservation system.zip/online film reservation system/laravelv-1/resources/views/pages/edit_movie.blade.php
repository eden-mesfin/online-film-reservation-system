<html>
@include('master.links')


<body>
<div>

</div>
@include('master.header')
<div class="faq">
    <div class="container">
        <div class="agileits-news-top">
            <ol class="breadcrumb">
                <li>Admin Page</li>
            </ol>
        </div>
        <div class="agileinfo-news-top-grids">
            <div class="col-md-12 wthree-top-news-left">
                <div class="wthree-news-left">
                    <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs" role="tablist" >
                            <li role="presentation"><a href="#home1" id="home1-tab" role="tab" data-toggle="tab" aria-controls="home1" aria-expanded="true">Edit Movie</a></li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                            <div role="tabpanel" class="tab-pane fade" id="home1" aria-labelledby="home1-tab">
                                <div class="wthree-news-top-left">
                                    <div class="col-md-6 w3-agileits-news-left">
                                        <div class="col-md-12 wthree-news-info">
                                            <form class="form-horizontal" action="{{action('UploadController@updateMovie',$movie->id)}}" method="post" enctype="multipart/form-data">
                                                {{csrf_field()}}
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Title</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="movie_title" value="{{$movie->movie_title}}">
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Thumbnail</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="file" class="form-control" name="movie_thumbnail" >
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Director</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="director" value="{{$movie->director}}">
                                                    </div>
                                                </div>
                                                <div class="form-group"  style="padding-bottom: 5%;">
                                                    <label for="inputEmail" class="control-label col-md-3">Movie Link</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="movie_link" value="{{$movie->movie_link}}">
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Plot Summary</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <textarea type="text" class="form-control" name="plot_summary" style="height:10%;">{{$movie->plot_summary}}</textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Running Time</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="number" step=".01" class="form-control" name="running_time" value="{{$movie->running_time}}">
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Release Date</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <input type="text" class="form-control" name="released_date" value="{{$movie->released_date}}">
                                                    </div>
                                                </div>
                                                <div class="form-group" style="padding-bottom: 5%;">
                                                    <label for="inputPassword" class="control-label col-md-3">Genres</label>
                                                    <div class="col-md-8 col-md-offset-1">
                                                        <select class="form-control genres" multiple="multiple" value="{{$movie->genres}}" name="genres">
                                                            <option>Action</option>
                                                            <option>Adventure</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="selectedGenres" class="form-control" id="selectedGenres" value="">
                                                <div class="form-group">
                                                    <div class="col-xs-offset-10 col-xs-10">
                                                        <button ONCLICK="check_function()" type="submit" class="btn" style="background: #FF8D1B;">Upload</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="clearfix"> </div>
    </div>
</div>

</div>


</body>
<script type="text/javascript">
    $(document).ready(function() {
        $(".genres").select2();
        $(".genres").select2();
    });
    function check_function()
    {
        document.getElementById("selectedGenres").value = $(".genres").val();

    }
</script>

@include('master.footer')
</html>