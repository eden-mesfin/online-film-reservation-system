
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
@include('master.links')

<body>

@include('master.header')

<!-- /w3l-medile-movies-grids -->
<div class="general-agileits-w3l">
    <div class="w3l-medile-movies-grids">

        <!-- /movie-browse-agile -->

        <div class="movie-browse-agile">
            <!--/browse-agile-w3ls -->
            <div class="browse-agile-w3ls general-w3ls">
                <div class="tittle-head">
                    <h4 class="latest-text">{{$needle}} Movies </h4>
                    <div class="container">
                        <div class="agileits-single-top">
                            <ol class="breadcrumb">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">Genres</li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="browse-inner">
                        @if($count==1)
                        @foreach($movies as $movie)
                        <div class="col-md-2 w3l-movie-gride-agile">
                            <a href="{{action('SingleController@single', ['movie_id'=>$movie->id])}}" class="hvr-shutter-out-horizontal"><img src="{{asset('Upload_movies/movies/'. $movie->id . '.jpg') }}" title="album-name" alt=" " />
                                <div class="w3l-action-icon"><i class="fa fa-play-circle" aria-hidden="true"></i></div>
                            </a>

                            <div class="mid-1">
                                <div class="w3l-movie-text">
                                    <h6><a href="{{action('SingleController@single', ['movie_id'=>$movie->id])}}">{{$movie->movie_title}}</a></h6>
                                </div>
                                <div class="mid-2">

                                    <p>{{date('d-m-y')}}</p>
                                    <div class="block-stars">
                                        <div class="ratebox" data-id="1" data-rating="{{$movie->rate['value']}}"></div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>

                            </div>

                            <div class="ribben two">
                                <p>NEW</p>
                            </div>
                        </div>
                        @endforeach
                        @else
                            <h2>No {{$needle}} Movies Found</h2>
                        @endif

                        <div class="clearfix"> </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- //movie-browse-agile -->
        <!--body wrapper start-->
        <!--body wrapper start-->
    </div>
    <!-- //w3l-medile-movies-grids -->
</div>

<script>
    function rateAlert(id, rating)
    {
        //alert( 'Rating for '+id+' is '+rating+' stars!' );
        var rating_value1 = rating;

    }

    $(function() {
        $( '.ratebox' ).raterater( {
            submitFunction: 'rateAlert',
            allowChange: true,
            numStars: 5
        } );
    });



</script>
{{--<form action="{{action('NotificationController@rating')}}" method="POST" id="form">--}}
    {{--{{ csrf_field() }}--}}
    {{--<input type="hidden" id = "autosubmit" name="value" value="" >--}}
    {{--<input type="hidden" id = "autosubmit" name="movie_id" value="{{$movie['id']}}" >--}}
{{--</form>--}}
<!-- //comedy-w3l-agileits -->

@include('master.footer')
</body>


</html>